const { Client, GatewayIntentBits, Partials } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { PREFIX } = require('./config');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel]
});

// ---- Command loader ----
const commands = new Map(); // commandName -> handler(message, args)
const aliasMap = new Map(); // alias -> canonicalName

function loadCommands() {
    const dir = path.join(__dirname, 'commands');
    if (!fs.existsSync(dir)) {
        console.warn('no commands directory found');
        return;
    }
    const files = fs.readdirSync(dir).filter(f => f.endsWith('.js'));
    for (const file of files) {
        const mod = require(path.join(dir, file));
        if (!mod || typeof mod.execute !== 'function') {
            console.warn(`skipping ${file}: missing execute()`);
            continue;
        }
        const name = mod.name || path.basename(file, '.js');
        commands.set(name, mod.execute);

        const aliases = Array.isArray(mod.aliases) ? mod.aliases : [];
        for (const a of aliases) aliasMap.set(a.toLowerCase(), name);

        // also register the file name as its own command
        aliasMap.set(path.basename(file, '.js').toLowerCase(), name);

        console.log(`✓ loaded command: ${name} [${aliases.join(', ') || 'no alias'}]`);
    }
}

client.once('ready', () => {
    console.log(`bot online as ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const input = args.shift().toLowerCase();

    const canonical = aliasMap.get(input) || input;
    const handler = commands.get(canonical);
    if (!handler) return;

    try {
        await handler(message, args);
    } catch (error) {
        console.error(`error in ${input} command:`, error);
        await message.reply(`error: ${error.message}`).catch(() => {});
    }
});

loadCommands();

const TOKEN = process.env.DISCORD_TOKEN;
if (!TOKEN) {
    console.error('❌ DISCORD_TOKEN is not set. Set it as an environment variable before running.');
    process.exit(1);
}
client.login(TOKEN);