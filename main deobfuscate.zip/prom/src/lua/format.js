'use strict';

const { Kind } = require('./ast');
const { KEYWORDS } = require('./tokens');

const BINARY = Object.freeze({
  or: [1, 'left'],
  and: [2, 'left'],
  '<': [3, 'left'],
  '>': [3, 'left'],
  '<=': [3, 'left'],
  '>=': [3, 'left'],
  '~=': [3, 'left'],
  '==': [3, 'left'],
  '|': [4, 'left'],
  '~': [5, 'left'],
  '&': [6, 'left'],
  '<<': [7, 'left'],
  '>>': [7, 'left'],
  '..': [8, 'right'],
  '+': [9, 'left'],
  '-': [9, 'left'],
  '*': [10, 'left'],
  '/': [10, 'left'],
  '//': [10, 'left'],
  '%': [10, 'left'],
  '^': [12, 'right'],
});

const UNARY_PREC = 11;
const ATOM_PREC = 100;

const PREFIXES = Object.freeze(new Set([Kind.Name, Kind.Index, Kind.Call, Kind.MethodCall, Kind.Paren]));

const ID_START = /[A-Za-z_]/;
const ID_BODY = /[A-Za-z0-9_]/;

const ESCAPES = Object.freeze({
  '\n': '\\n',
  '\r': '\\r',
  '\t': '\\t',
  '\\': '\\\\',
  '"': '\\"',
  '\b': '\\b',
  '\f': '\\f',
  '\v': '\\v',
});

function isIdentifier(text) {
  if (typeof text !== 'string' || text.length === 0) return false;
  if (!ID_START.test(text[0])) return false;
  for (let i = 1; i < text.length; i++) {
    if (!ID_BODY.test(text[i])) return false;
  }
  return !KEYWORDS.has(text);
}

function formatNumber(value) {
  if (typeof value !== 'number') return String(value);
  if (Number.isNaN(value)) return '(0 / 0)';
  if (value === Infinity) return 'math.huge';
  if (value === -Infinity) return '-math.huge';
  if (Object.is(value, -0)) return '-0';
  if (Number.isInteger(value) && Math.abs(value) < 1e15) return String(value);
  return String(value);
}

function utf8Length(value, at) {
  const lead = value.charCodeAt(at);
  if (lead < 0xc2 || lead > 0xf4) return 0;
  const second = value.charCodeAt(at + 1);
  const third = value.charCodeAt(at + 2);
  const fourth = value.charCodeAt(at + 3);

  const isContinuation = (code) => code >= 0x80 && code <= 0xbf;

  let length = 0;
  let point = 0;

  if (lead >= 0xc2 && lead <= 0xdf) {
    if (!isContinuation(second)) return 0;
    length = 2;
    point = ((lead & 0x1f) << 6) | (second & 0x3f);
  } else if (lead >= 0xe0 && lead <= 0xef) {
    if (!isContinuation(second) || !isContinuation(third)) return 0;
    length = 3;
    point = ((lead & 0x0f) << 12) | ((second & 0x3f) << 6) | (third & 0x3f);
    if (point < 0x800 || (point >= 0xd800 && point <= 0xdfff)) return 0;
  } else if (lead >= 0xf0 && lead <= 0xf4) {
    if (!isContinuation(second) || !isContinuation(third) || !isContinuation(fourth)) return 0;
    length = 4;
    point = ((lead & 0x07) << 18) | ((second & 0x3f) << 12) |
            ((third & 0x3f) << 6) | (fourth & 0x3f);
    if (point < 0x10000 || point > 0x10ffff) return 0;
  } else {
    return 0;
  }

  if (point <= 0x9f) return 0;
  return length;
}

function quoteString(value) {
  let out = '"';
  let i = 0;
  while (i < value.length) {
    const c = value[i];
    const short = ESCAPES[c];
    if (short !== undefined) {
      out += short;
      i++;
      continue;
    }
    const code = value.charCodeAt(i);
    if (code >= 0x20 && code <= 0x7e && code !== 0x22 && code !== 0x5c) {
      out += c;
      i++;
      continue;
    }
    if (code >= 0xc2 && code <= 0xf4) {
      const spelled = utf8Length(value, i);
      if (spelled) {
        out += value.slice(i, i + spelled);
        i += spelled;
        continue;
      }
    }
    const next = value[i + 1];
    const needsPadding = next !== undefined && next >= '0' && next <= '9';
    out += `\\${needsPadding ? String(code).padStart(3, '0') : String(code)}`;
    i++;
  }
  return out + '"';
}

function canUseLongBracket(value) {
  if (!value.includes('\n')) return false;
  if (value.includes(']]')) return false;
  if (value.startsWith('\n')) return false;
  if (value.endsWith(']')) return false;
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    const printable = (code >= 0x20 && code <= 0x7e) || code === 0x0a || code === 0x09;
    if (!printable) return false;
  }
  return true;
}

function formatString(value) {
  if (canUseLongBracket(value)) return `[[\n${value}]]`;
  return quoteString(value);
}

function getBinaryPrecedence(operator) {
  const info = BINARY[operator];
  return info ? info[0] : 0;
}

function getBinaryAssociativity(operator) {
  const info = BINARY[operator];
  return info ? info[1] : 'left';
}

function isBinaryOperator(operator) {
  return operator in BINARY;
}

module.exports = {
  BINARY,
  UNARY_PREC,
  ATOM_PREC,
  PREFIXES,
  isIdentifier,
  formatNumber,
  formatString,
  getBinaryPrecedence,
  getBinaryAssociativity,
  isBinaryOperator,
};