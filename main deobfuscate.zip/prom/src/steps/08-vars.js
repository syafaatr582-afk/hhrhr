'use strict';

const { Kind } = require('../lua/ast');
const { walk } = require('../lua/walk');
const { isIdentifier } = require('../lua/format');
const { isGlobalName } = require('../lua/scope');

const LOOP_COUNTERS = ['i', 'j', 'k', 'm', 'n'];
const MAX_NAME_ATTEMPTS = 100000;

function collectReservedNames(chunk) {
  const taken = new Set([
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function', 'goto', 'if',
    'in', 'local', 'nil', 'not', 'or', 'repeat', 'return', 'then', 'true', 'until', 'while',
    'self', '_ENV',
  ]);
  
  walk(chunk, {
    enter(node) {
      if (isGlobalName(node)) taken.add(node.name);
      return undefined;
    },
  });
  
  return taken;
}

function createNameGenerator(takenNames) {
  const categoryCounters = { p: 0, f: 0, v: 0, i: 0 };
  
  return function generateName(category) {
    for (let attempt = 0; attempt < MAX_NAME_ATTEMPTS; attempt += 1) {
      categoryCounters[category] += 1;
      const counter = categoryCounters[category];
      
      const candidate = category === 'i' && counter <= LOOP_COUNTERS.length
        ? LOOP_COUNTERS[counter - 1]
        : `${category}${counter}`;
      
      if (!takenNames.has(candidate) && isIdentifier(candidate)) {
        takenNames.add(candidate);
        return candidate;
      }
    }
    
    throw new Error('rename: name pool exhausted');
  };
}

function findFunctionBindings(chunk) {
  const bindingUsage = new Map();
  
  const trackUsage = (target, value) => {
    if (!target || target.kind !== Kind.Name || !target.binding) return;
    
    const usage = bindingUsage.get(target.binding) || { functions: 0, other: 0 };
    if (value && value.kind === Kind.Function) {
      usage.functions += 1;
    } else {
      usage.other += 1;
    }
    bindingUsage.set(target.binding, usage);
  };
  
  walk(chunk, {
    enter(node) {
      if (node.kind === Kind.FunctionDeclaration) {
        trackUsage(node.target, node.body);
      } else if (node.kind === Kind.Assignment) {
        const values = node.expressions || [];
        const targets = node.targets || [];
        const isAligned = values.length === targets.length;
        targets.forEach((target, index) => {
          trackUsage(target, isAligned ? values[index] : null);
        });
      }
      return undefined;
    },
  });
  
  const functionBindings = new Set();
  for (const [binding, usage] of bindingUsage) {
    if (usage.functions > 0 && usage.other === 0) {
      functionBindings.add(binding);
    }
  }
  
  return functionBindings;
}

function categorizeBindings(chunk) {
  const bindingCategories = new Map();
  const functionBindings = findFunctionBindings(chunk);
  
  const assignCategory = (binding, category) => {
    if (!binding || bindingCategories.has(binding)) return;
    bindingCategories.set(binding, category);
  };
  
  walk(chunk, {
    enter(node) {
      if (node.kind === Kind.Function) {
        (node.bindings || []).forEach((binding, index) => {
          if ((node.params || [])[index] === 'self') return;
          assignCategory(binding, 'p');
        });
      } else if (node.kind === Kind.LocalFunction) {
        assignCategory(node.binding, 'f');
      } else if (node.kind === Kind.NumericFor) {
        assignCategory(node.binding, 'i');
      } else if (node.kind === Kind.GenericFor) {
        (node.bindings || []).forEach((binding) => assignCategory(binding, 'r'));
      } else if (node.kind === Kind.LocalDeclaration) {
        const expressions = node.expressions || [];
        const isAligned = expressions.length === (node.names || []).length;
        (node.bindings || []).forEach((binding, index) => {
          const value = isAligned ? expressions[index] : null;
          const holdsFunction = (value && value.kind === Kind.Function) || functionBindings.has(binding);
          assignCategory(binding, holdsFunction ? 'f' : 'r');
        });
      }
      return undefined;
    },
  });
  
  return bindingCategories;
}

function createRenamePlan(chunk, generateName) {
  const renameMap = new Map();
  
  for (const [binding, category] of categorizeBindings(chunk)) {
    renameMap.set(binding, generateName(category));
  }
  
  return renameMap;
}

function applyRenames(chunk, renameMap) {
  let mentionCount = 0;
  
  const rewriteList = (items, bindings) => {
    if (!items || !bindings) return;
    
    for (let i = 0; i < bindings.length && i < items.length; i += 1) {
      const newName = renameMap.get(bindings[i]);
      if (newName) items[i] = newName;
    }
  };
  
  walk(chunk, {
    enter(node) {
      if (node.kind === Kind.Function) {
        rewriteList(node.params, node.bindings);
      } else if (node.kind === Kind.LocalDeclaration) {
        rewriteList(node.names, node.bindings);
      } else if (node.kind === Kind.GenericFor) {
        rewriteList(node.variables, node.bindings);
      } else if (node.kind === Kind.LocalFunction) {
        const newName = renameMap.get(node.binding);
        if (newName) node.name = newName;
      } else if (node.kind === Kind.NumericFor) {
        const newName = renameMap.get(node.binding);
        if (newName) node.variable = newName;
      } else if (node.kind === Kind.Name && node.binding) {
        const newName = renameMap.get(node.binding);
        if (newName && node.name !== newName) {
          node.name = newName;
          mentionCount += 1;
        }
      }
      return undefined;
    },
  });
  
  return mentionCount;
}

function run(context) {
  context.resolve();
  
  const reservedNames = collectReservedNames(context.chunk);
  const renameMap = createRenamePlan(context.chunk, createNameGenerator(reservedNames));
  
  if (!renameMap.size) return;
  
  const mentionCount = applyRenames(context.chunk, renameMap);
  
  context.resolve();
  context.note(`renamed ${renameMap.size} local(s)`, renameMap.size);
  context.bump('rename.bindings', renameMap.size);
  context.bump('rename.mentions', mentionCount);
}

module.exports = {
  name: '08-vars',
  run,
  reserved: collectReservedNames,
  namer: createNameGenerator,
  categories: categorizeBindings,
  plan: createRenamePlan,
  apply: applyRenames,
};