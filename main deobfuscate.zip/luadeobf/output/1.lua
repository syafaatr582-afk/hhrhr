-- Deоbfuѕсаtеԁ by LeakD | discord.gg/qteAQmfJmP

local function main(r0)
  local function main_f0()
    local function main_f0_f0(r0)
      r0.Character()
    end
    local function main_f0_f1(r0)
    end
    local function main_f0_f2(r0)
    end
    local function main_f0_f3(r0)
      if r6 == nil then
      end
    end
    local function main_f0_f4(r0)
      local function main_f0_f4_f0()
        ::L2::
        ::L5::
        goto L40
        r3.SendKeyEvent(0, 0, "game")
        task.wait(0.05)
        goto L5
        goto L2
      end
      pcall(main_f0_f4_f0)
    end
    local function main_f0_f5(r0)
      local function main_f0_f5_f0()
        TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
        0.2(Enum.EasingStyle.Quad)
        r5 = Enum.EasingStyle.Quad(Enum.EasingDirection.Out)
        r5 = r5("Size")
        r6 = UDim2.new(r8.X.Offset[4], r9.Y.Scale, r10.Y.Offset[4])
        0.2(r5, r6, nil, r8.X.Offset[4])
        r0.Play()
      end
      local function main_f0_f5_f1()
        TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
        0.1(Enum.EasingStyle.Quad)
        r5 = Enum.EasingStyle.Quad(Enum.EasingDirection.Out)
        r5 = r5("Size", "b\t*`")
        r6 = UDim2.new("b\t*`".X.Scale, r8.X.Offset[4], r9.Y.Scale, r10.Y.Offset[4])
        0.1(r5, r6, "b\t*`".X.Scale, r8.X.Offset[4])
        r0.Play()
      end
      local function main_f0_f5_f2()
        TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
        0.2(Enum.EasingStyle.Quad)
        r5 = Enum.EasingStyle.Quad(Enum.EasingDirection.Out)
        r5 = r5(Size, "'~Z\u000fT-4")
        r6 = Size("'~Z\u000fT-4")
        0.2(r5, r6, "'~Z\u000fT-4")
        r0.Play()
      end
      local function main_f0_f5_f3()
        TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
        0.1(Enum.EasingStyle.Quad)
        r5 = Enum.EasingStyle.Quad(Enum.EasingDirection.Out)
        r5 = r5("Size")
        r6 = UDim2.new(r8.X.Offset[6], r9.Y.Scale, r10.Y.Offset[6])
        0.1(r5, r6, nil, r8.X.Offset[6])
        r0.Play()
      end
      ::L5::
      r0.MouseEnter.Connect(main_f0_f5_f0)
      r0.MouseButton1Up.Connect(main_f0_f5_f1)
      goto L53
      r0.MouseLeave.Connect(main_f0_f5_f1, main_f0_f5_f2)
      r0.MouseButton1Down.Connect(main_f0_f5_f1, main_f0_f5_f3)
      goto L5
      goto L5
    end
    local function main_f0_f6(r0, r1)
      local function main_f0_f6_f0()
        local function main_f0_f6_f0_f0()
          ::L5::
          r2.Destroy()
          goto L5
        end
        ::L8::
        r6 = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
        r8 = Enum.EasingStyle.Quint("Position", "i1x4\u0016#1i")
        r9 = UDim2.new(0.5, -170, 0, -80)
        r7 = main_f0_f6_f0_f0(r8, r9, 0.5, -170, 0, -80)
        r3.Create(r6, r7)
        r1.Play()
        r1.Completed.Connect(main_f0_f6_f0_f0)
        goto L8
      end
      ::L43::
      r8 = ("BackgroundColor3" + r9.Panel)()
      r8.BorderSizePixel = 0
      r8()
      r9 = r9.Panel()
      r8 = ("BackgroundColor3" + r9.Panel)()
      r8.ZIndex = 100
      r9 = r9.Panel()
      r9("z|W\u0007][q\u001a", "h/5\u0014")
      goto L43
      ::L133::
      r7 = Color3.fromRGB(255, 210, 120)
      ("TextColor3" + r7).TextSize = 16
      Enum.Font.GothamBold()
      goto L133
    end
    local function main_f0_f8()
      local function main_f0_f8_f0()
      end
      local function main_f0_f8_f2()
      end
      ::L5::
      ::L10::
      goto L229
      ::L61::
      if r4 == r0 then
        main_f0_f8_f2(main_f0_f8_f0)
      end
      goto L61
      goto L10
      goto L10
      goto L5
    end
    local function main_f0_f9()
      ::L4::
      r0()
      goto L4
    end
    local function main_f0_f10(r0)
      local function main_f0_f10_f0()
        ::L1::
        if nil == 0.5 then
          nil.LocalTransparencyModifier = 0.5
        end
        goto L1
      end
      ::L2::
      if r0.Name == r4 then
        if r0.Transparency == 1 then
          r0.Name.lower()
        end
      end
      nil.LocalTransparencyModifier = 0.5
      r0(1)
      main_f0_f10_f0()
      table.insert()
      goto L2
    end
    local function main_f0_f11(r0)
      local function main_f0_f11_f0(r0)
      end
      ::L5::
      ::L10::
      goto L48
      goto L10
      ::L31::
      goto L31
      goto L5
    end
    local function main_f0_f12()
      ::L45::
      1()
      1()
      r4 = 1()
      if r4 == nil then
        r5 = ("Text" + r6)("Invis: On [T]")
        r8 = TweenInfo.new(0.3)
        0.3()
        r11 = BackgroundColor3()
        r9 = 0.3(r11.InvisOn)
        r5 = r5.Create("Invis: On [T]", r8, r9)
        r5.Play()
      end
      goto L45
    end
    local function main_f0_f13()
      local function main_f0_f13_f0()
      end
      local function main_f0_f13_f1()
        ::L2::
        if r2.IsPlaying == 0 then
          r2 = r2.IsPlaying()
        end
        r2.IsPlaying()
        r2 = r2.IsPlaying()
        r2.Destroy()
        goto L21
        goto L2
      end
      ::L89::
      goto L110
      goto L89
        if r3 == r0 then
          if ("Velocity" + r6) == r1 then else goto L392 end
        end
        r13 = r0()
        if r3.Health == 0 then
          r13 = r13()
          r13()
        end
        1(0, r13)
        r11 = 1(0, r13)
        r11 = r11(0, r13)
        r13 = r13()
        r13("AbsoluteImmortal")
        if r8 == nil then
          if r7 == nil then
            r11.Character.SetAttribute()
            r16 = r11.Character.SetAttribute("nz\"CÃ_)")
          end
        end
      end
      r10 = 1(r11)
      if r10 == r0 then
        ::L123::
        if r12 == r3 then
          if r14 == r0 then
            pcall(main_f0_f13_f1)
            r15 = pcall(main_f0_f13_f1)
            r15(main_f0_f13_f1)
          end
        end
        if nil == r0 then
          r16.Play()
          r16 = r16.Play()
          r16.AdjustSpeed(0)
        end
      end
      goto L123
    end
    local function main_f0_f14(r0)
      ::L7::
      goto L7
    end
    local function main_f0_f15(r0)
      r0.CFrame.ToEulerAnglesYXZ()
    end
    local function main_f0_f16()
      ::L5::
      goto L5
    end
    local function main_f0_f17()
      ::L1::
      goto L25
        ::L12::
        r2.Disconnect()
      end
      goto L12
      goto L1
    end
    local function main_f0_f18()
      local function main_f0_f18_f0()
        local function main_f0_f18_f0_f0()
        end
        ::L5::
        if getgenv.desync == r1 then
          r8 = getgenv.desync()
          r8()
        end
        if "sethiddenproperty" == r0 then
          PhysicsRepRootPart("r_\n|")
        end
        if "sethiddenproperty" == r0 then
          if r10 == r1 then
            main_f0_f18_f0_f0("hUA.", "\u000bvåT", "LeftClick", "8Dem2")
            task.wait(0.05)
          end
        end
        goto L5
      end
    end
    local function main_f0_f19()
      r0()
      r1 = 1()
      if r1 == r0 then
        ::L7::
        r5 = TweenInfo.new(0.3)
        0.3()
        r8 = BackgroundColor3("XIÌP")
        r6 = 0.3(r8.SpectateOff, "XIÌP")
        r2 = ("Text" + r3)("Spectate [Y]", r5, r6)
        r2.Play()
      end
      goto L7
      r3.Disconnect()
      r2 = ("CameraType" + Enum.CameraType.Custom)(Enum.CameraType.Custom)
      if r2.Character == r0 then
        r2.Character(Enum.CameraType.Custom)
        Enum.CameraType.Custom()
      end
    end
    local function main_f0_f20(r0)
      local function main_f0_f20_f0(r0)
        ::L5::
        if r3 == 0 then
          r2.FindFirstChild("Head")
        end
        r10 = math.exp()
        r10 = (1 + r10)()
        CFrame.new(r10)
        goto L5
      end
    end
    local function main_f0_f21(r0, r1)
      ::L2::
      if r4 == Enum.UserInputType.MouseButton2 then
        if r4 == r0 then
          r5 = r1()
          r5()
        end
      end
      goto L2
    end
    local function main_f0_f22(r0, r1)
      ::L2::
      if r4 == Enum.UserInputType.MouseButton2 then
        if r4 == r0 then
          r6 = r0()
          r6()
        end
      end
      goto L2
    end
    local function main_f0_f23(r0, r1)
      ::L4::
      if r3 == Enum.UserInputType.MouseMovement then
        if r3 == r0 then
          if r3 == r0 then
            r6 = r0.Delta.X[0.005]()
            r6 = r6(r0.Delta.Y[0.005])
            r5 = math.clamp(r6, -1.5, 0.5)
            r5(r6, -1.5)
          end
        end
      end
      if r0.UserInputType == Enum.UserInputType.MouseWheel then
        r3 = r0.UserInputType()
        if r3 == r0 then
          r3 = math.clamp(2, 50)
          r3()
        end
      end
      goto L4
    end
    local function main_f0_f24()
      local function main_f0_f24_f0()
        Vector2.new()
      end
      ::L2::
      main_f0_f24_f0.Idled.Connect(main_f0_f24_f0)
      goto L2
    end
    local function main_f0_f25()
      ::L1::
      goto L36
      ::L21::
      goto L1
      goto L21
      goto L1
    end
    local function main_f0_f26()
    end
    local function main_f0_f27()
      ::L1::
      if r1 == 0 then
        r3 = ("Text" + r4)("Auto Combat: On")
        r6 = TweenInfo.new(0.2)
        0.2()
        r9 = BackgroundColor3()
        r7 = 0.2(r9.CombatOn)
        r3 = r3.Create("Auto Combat: On", r6, r7)
        r3.Play()
      end
      goto L98
      r2 = ("Text" + nil)("Auto Combat: Off")
      r5 = TweenInfo.new(0.2)
      0.2()
      r8 = BackgroundColor3()
      r6 = 0.2(r8.CombatOff)
      r2 = r2.Create("Auto Combat: Off", r5, r6)
      r2.Play()
      goto L98
      goto L1
    end
    local function main_f0_f28(r0)
      r4 = ("Visible" + r5)()
      if r2 == r0 then
        if r5.FollowOff == r1 then else goto L42 end
      end
      ::L5::
      1()
      if r2 == r0 then
        if r4.TextPrimary == r1 then else goto L13 end
      end
      ("TextColor3" + r4.TextDim)(r4.TextDim)
      if r2 == r0 then
        r4 = r4.TextDim()
        if r4.Panel == r1 then else goto L23 end
      end
      goto L23
      ("BackgroundColor3" + r4.FollowOff)(r4.FollowOff)
      if r2 == r0 then
        r4 = r4.FollowOff()
        if r4.TextDim == r1 then else goto L73 end
      end
      goto L73
      goto L5
    end
    local function main_f0_f29()
    end
    local function main_f0_f30()
    end
    local function main_f0_f31()
      local function main_f0_f31_f0()
        0.Visible = false
        0.Text = "Public Kill â¢ Loaded"
      end
      r3 = main_f0_f31_f0()
      r3("Loading ...", "{\tar")
      task.spawn(main_f0_f31_f0)
    end
    local function main_f0_f32()
      local function main_f0_f32_f0()
        TweenInfo.new(0.2)
        0.2()
        r6 = BackgroundColor3()
        0.2(r6.Stroke)
        r0.Play()
      end
      local function main_f0_f32_f2()
        r0 = ("Text" + r1)("\\nl".Name, ")")
        r0.Visible = false
        r0("\\nl".Name, ")")
        ::L20::
        goto L20
        ::L33::
        goto L33
      end
      r1 = r1.GetChildren()
      r0 = pairs(r1)
      ::L6::
      goto L6
      goto L147
      end
      r2(r0)
      UDim2.new(0, 0, 0, 0)
    end
    local function main_f0_f33()
      ::L2::
      r3.Visible()
      goto L18
      goto L2
    end
    local function main_f0_f34()
      ::L2::
      ::L5::
      goto L141
      if r3 == 0 then
      end
      r4 = ("Text" + r5)()
      r7 = TweenInfo.new(0.3)
      0.3()
      r10 = BackgroundColor3("81Èd|w")
      r8 = 0.3(r10.FollowOff, "81Èd|w")
      r4 = r4.Create("Start Follow [R]", r7, r8)
      r4.Play()
      goto L5
      goto L2
    end
    local function main_f0_f35()
    end
    local function main_f0_f36()
      goto L44
      ::L8::
      if nil == 0 then
        ::L18::
      end
      goto L18
      goto L8
    end
    local function main_f0_f37()
      ::L2::
      ::L5::
      goto L122
      if r3 == 0 then
        r6 = ("Text" + r7)("Auto Combat: On [G]")
        r9 = TweenInfo.new(0.3)
        0.3()
        r12 = BackgroundColor3()
        r10 = 0.3(r12.CombatOn)
        r6 = r6.Create("Auto Combat: On [G]", r9, r10)
        r6.Play()
      end
      r5 = ("Text" + r6)("Auto Combat: Off [G]", "zG2lM{")
      r8 = TweenInfo.new(0.3)
      0.3()
      r11 = BackgroundColor3()
      r9 = 0.3(r11.CombatOff)
      r5 = r5.Create("Auto Combat: Off [G]", r8, r9)
      r5.Play()
      goto L5
      goto L2
    end
    local function main_f0_f38()
      ::L2::
      if r2 == 0 then
        r4 = ("Text" + r5)("Auto Combat: On", "Dz}^xU")
        r7 = TweenInfo.new(0.3)
        0.3()
        r10 = BackgroundColor3("7_&.~T")
        r8 = 0.3(r10.CombatOn, "7_&.~T")
        r4 = r4.Create("Auto Combat: On", r7, r8)
        r4.Play()
      end
      goto L76
      goto L2
    end
    local function main_f0_f39()
      ::L42::
      if r3.Character == r0 then else goto L42 end
      goto L42
    end
    local function main_f0_f40()
      ::L155::
      ::L5::
      ::L23::
      r8 = 3.GetDescendants()
      ipairs(r8)
      r12 = r11.IsA("Model")
      if r12 == r0 then
        r12 = r11.Name("Model")
        if r12 == 3 then
          r12 = r11.FindFirstChildOfClass(Humanoid)
          Humanoid()
          r13 = r11.FindFirstChild("HumanoidRootPart")
          if r12 == r0 then
          end
        end
      end
      goto L23
      goto L5
        r9 = Vector3.new(0, 4, 0)
        r9 = r9(0)
        r9(Success)
        Success()
      end
      goto L155
    end
    local function main_f0_f41(r0, r1)
      ::L2::
      goto L45
      goto L45
      goto L45
      goto L2
    end
    local function main_f0_f42()
      r3 = r0()
      if r3 == r0 then
        r3 = r3()
        if r3 == r0 then
          table.insert()
        end
      end
      r3 = r3()
      if r3 == r0 then
        r3 = r3()
      end
      r3()
      ::L97::
      if nil == r0 then
      end
      if r1 == 0 then
        r1()
      end
      goto L97
    end
    local function main_f0_f43(r0)
      local function main_f0_f43_f0()
      end
      local function main_f0_f43_f1()
        ::L1::
        r1.WaitForChild(5)
        r1 = r1.WaitForChild()
        if r1 == 0 then
          r1 = r1()
          r1()
        end
        goto L1
      end
      ::L2::
      pairs()
      pcall(main_f0_f43_f0)
      main_f0_f43_f0(r0)
      ::L24::
      goto L24
          task.wait(0.5)
          task.wait(0.5)
        end
      end
      goto L2
    end
    local function main_f0_f44()
      ::L1::
      task.wait(0.15)
      0.15()
      if r3.Character == 1 then else goto L1 end
      if r3 == 1 then else goto L1 end
      r3.Character.FindFirstChildOfClass("Humanoid")
      goto L1
    end
    getgenv.InvisScriptExecuted = true
    r3 = Players("(En(\\2")
    r3(RunService, "8ê}V]agd")
    r4 = RunService("8ê}V]agd")
    r4(Workspace, "B_h3")
    r5 = Workspace("B_h3")
    r5(CoreGui)
    r6 = CoreGui()
    r6(UserInputService, "aIWBQ-")
    r7 = UserInputService("aIWBQ-")
    r7(TweenService, "sqt1")
    r8 = TweenService("sqt1")
    r8(VirtualInputManager, "0xml")
    main_f0_f12("Uù?? ".T)
    main_f0_f12("Spectate".Y)
    Model("hm\"\nE")
    Humanoid("wiq{b")
    main_f0_f29("4DV>")
    Instance.new.Transparency = 1
    Instance.new.Anchored = true
    2(2, 1)
    Enum.KeyCode.Two(Enum.KeyCode.Three)
    Enum.KeyCode.One("17799224866")
    main_f0_f0.InputBegan.Connect(main_f0_f21)
    main_f0_f0.InputEnded.Connect(main_f0_f22)
    main_f0_f0.InputChanged.Connect(main_f0_f23)
    r67 = main_f0_f23()
    r67 = r67("ScreenGui", "bQjdHr")
    r67 = r67("ScreenGui", "ja]1")
    ("Name" + r67).ResetOnSpawn = false
    UDim2.fromScale(0.5, 0.5)
    Vector2.new(0.5, 0.5)
    ("BackgroundColor3" + main_f0_f0.Background).BorderSizePixel = 0
    ("Parent" + ("Parent" + main_f0_f0)).Active = true
    ("Parent" + ("Parent" + main_f0_f0)).Draggable = true
    r69 = 0.5(0.5)
    r69 = r69("UICorner", "h\\z dm")
    r69(0, 10)
    main_f0_f0.Thickness = 1
    r71 = UDim2.fromOffset(0, 0)
    ("Position" + r71).BackgroundTransparency = 1
    r71 = r71(0)
    r71("GALAXY HUB")
    ("TextColor3" + main_f0_f0.TextPrimary).TextSize = 15
    UDim2.fromOffset(10, 42)
    r72 = main_f0_f0.FollowOff(10)
    r72("Target Farm", "0daEOgL")
    ("TextColor3" + main_f0_f0.TextPrimary).TextSize = 12
    ("Font" + Enum.Font.GothamBold).AutoButtonColor = false
    UDim2.fromOffset(185, 42)
    r74 = main_f0_f0.Panel(185)
    r74("Rage Kill", "?f*`'")
    ("TextColor3" + main_f0_f0.TextDim).TextSize = 12
    ("Font" + Enum.Font.GothamBold).AutoButtonColor = false
    UDim2.new(1, 0, 1, -78)
    r76 = UDim2.fromOffset(0, 78)
    ("Position" + r76).BackgroundTransparency = 1
    UDim2.new(1, 0, 1, -78)
    r77 = UDim2.fromOffset(0, 78)
    ("Position" + r77).BackgroundTransparency = 1
    ("Position" + r77).Visible = false
    r78 = UDim2.fromOffset(15, 10)
    ("Position" + r78).BackgroundTransparency = 1
    r78 = r78(15)
    r78("Public Kill", "0xvT")
    ("TextColor3" + main_f0_f0.TextPrimary).TextSize = 14
    UDim2.fromOffset(15, 52)
    r79 = main_f0_f0.FollowOff(15)
    r79("Load Rage Kill", "TwJww")
    ("TextColor3" + main_f0_f0.TextPrimary).TextSize = 13
    ("Font" + Enum.Font.GothamBold).AutoButtonColor = false
    UDim2.fromOffset(15, 105)
    r81 = main_f0_f0.CombatOff(15)
    r81("Auto Combat: Off")
    ("TextColor3" + main_f0_f0.TextPrimary).TextSize = 13
    UDim2.fromOffset(15, 148)
    r83 = 1(15)
    r83("Recommended: Use Martial Artist Character before using Rage Farm.")
    ("Font" + Enum.Font)(TextWrapped, main_f0_f0, nil, 0, 30)
    main_f0_f4(Enum.KeyCode.One, Enum.KeyCode.Two, Enum.KeyCode.Three)
    MouseButton1Click.Connect(Enum.KeyCode.Four, main_f0_f27)
    MouseButton1Click.Connect(main_f0_f29)
    MouseButton1Click.Connect(main_f0_f30)
    MouseButton1Click.Connect(main_f0_f31)
    MouseButton1Click.Connect(main_f0_f31)
    main_f0_f0.new(0.9, 0, 0, 35)
    UDim2.fromScale(0.05, 0.14)
    r94 = main_f0_f0.Panel(0.05)
    r94("Select Target...", "NS1B{=")
    r95 = Gotham("NS1B{=")
    r95 = r95("UICorner", "W2Ow")
    r95 = r95(0, 6)
    r95(0, 6, 35)
    UDim2.fromScale(0.05, 0.27)
    ("Visible" + main_f0_f0)("ZIndex", 15, 0.27, 0, 130)
    r95 = ("Parent" + ("Parent" + ("Parent" + ("Parent" + main_f0_f0))))("ScrollBarImageColor3", main_f0_f0.Stroke, 0.27, 0, 130)
    r95("ScrollBarThickness", 4, 0.27, 0, 130)
    r97 = 4(0.27)
    r97 = r97("UICorner")
    r97(0, 6)
    main_f0_f0(0, UIListLayout, "LayoutOrder")
    r99 = MouseButton1Click("LayoutOrder")
    r99.Connect("LayoutOrder", main_f0_f33)
    UDim2.fromScale(0.05, 0.29)
    r101 = 0.05(0.29)
    r101 = r101("UIGridLayout", "\rp§?0vP")
    r100 = main_f0_f0(r101, "UIGridLayout".new, 0, 10, 0, 10)
    r102 = UDim2.new(0.48, -5, 0, 38)
    r100("CellSize", r102, 0.48, -5, 0, 38)
    r102 = r102(0.48)
    r102 = r102("TextButton", "S<xOIx")
    r101 = main_f0_f0(r102)
    r101("Start Follow [R]")
    r102 = main_f0_f0(0, "TextButton", "2a\"Q=!", 38)
    r102 = r102(0)
    r102("Spectate [Y]", "E:?sÁ@H")
    r103 = main_f0_f0(0, "TextButton", "O+>W(")
    r103 = r103(0)
    r103("Invis: Off [T]")
    r104 = main_f0_f0(0)
    r104("Auto Combat: Off [G]", "9S[7")
    UDim2.fromScale(0, 0.88)
    r110 = 1(0)
    r110("Awaiting Target Selection...", "@b`A")
    r114 = MouseButton1Click()
    r114.Connect()
    r114 = MouseButton1Click()
    r114.Connect()
    r114 = MouseButton1Click()
    r114.Connect()
    r114 = MouseButton1Click()
    r114.Connect()
    MouseButton1Click.Connect(main_f0_f38)
    MouseButton1Click.Connect(main_f0_f39)
    MouseButton1Click.Connect(main_f0_f40)
    main_f0_f0.InputBegan.Connect(main_f0_f41)
    main_f0_f0.InputBegan.Connect(main_f0_f41)
    r116 = main_f0_f41()
    main_f0_f1.Connect(r116)
    r116 = r116()
    PlayerRemoving.Connect(r116)
    PlayerRemoving.Connect(r116)
    r114 = main_f0_f1(r116)
    r114.Connect(main_f0_f43)
  end
  local function main_f2(r0)
    local function main_f2_f0()
    end
    if r0.UserInputType == Enum.UserInputType.MouseButton1 then
      if r0.UserInputType == Enum.UserInputType.Touch then else goto L33 end
    end
    goto L33
    ::L13::
    r0.Position()
    Enum.UserInputType.MouseButton1().Position()
    r0.Changed.Connect(main_f2_f0)
    goto L13
  end
  local function main_f3(r0)
    Enum.UserInputType.MouseMovement()
    r5 = r5.X.Offset(r1.X)
    r6 = r1.X()
    r7 = r7.Y.Offset(r1.Y)
    UDim2.new(r4.X.Scale, r5, r6.Y.Scale, r7)
  end
  local function main_f4(r0, r1)
    local function main_f4_f0()
      TweenInfo.new(0.15)
      0.15()
      r6 = BackgroundColor3()
      0.15(r6)
      r0.Play()
    end
    local function main_f4_f1()
      TweenInfo.new(0.15)
      0.15()
      r6 = BackgroundColor3()
      0.15(r6)
      r0.Play()
    end
    r5 = math.min(r1.R[255][20], 255)
    math.min(r1.G[255][20], 255)
    math.min(r1.B[255][20], 255)
    main_f4_f0.Connect(r5, main_f4_f1)
    r0.MouseLeave.Connect(r5, main_f4_f0)
  end
  local function main_f6()
    local function main_f6_f0()
      TweenInfo.new(0.05)
      0.05()
      r6 = Position()
      0.05(r6)
    end
    ::L1::
    r4 = 2()
    r4()
    goto L145
    ::L107::
    ("Text" + r5)()
    Color3.fromRGB(235, 80, 80)
    goto L107
    goto L1
  end
  local function main_f7(r0)
  end
  r7 = CoreGui()
  r7(TweenService, "6?HÎd")
  r8 = TweenService("6?HÎd")
  r8 = r8("UserInputService", "+347'+")
  r8 = r8("UserInputService")
  r8 = r8("ScreenGui", "hwSé")
  r8 = r8("ScreenGui")
  ("Name" + r8).ResetOnSpawn = false
  ("Size" + "ScreenGui").BackgroundTransparency = 1
  r10 = 1(1)
  r10 = r10("Frame", "~§n5")
  r10(390, 250)
  UDim2.fromScale(0.5, 0.5)
  Vector2.new(0.5, 0.5)
  r10 = Color3.fromRGB(18, 19, 24)
  ("BackgroundColor3" + r10).BorderSizePixel = 0
  ("BackgroundColor3" + r10).Active = true
  r11 = 18(19)
  r11 = r11("UICorner")
  r11(0, 14)
  ("Color" + 0).Thickness = 1.5
  r13 = 55(58, 72)
  72()
  r13 = r13(58)
  r13 = r13("TextLabel", "z\n\tK6\u0014D)")
  r13(1, -40, 0, 32)
  r13 = UDim2.fromOffset(20, 18)
  ("Position" + r13).BackgroundTransparency = 1
  r13 = r13(20)
  r13("GALAXY HUB")
  r13 = Color3.fromRGB(245, 245, 250)
  ("TextColor3" + r13).TextSize = 20
  r14 = 245(245)
  r14 = r14("TextLabel")
  r14(1, -40, 0, 24)
  r14 = UDim2.fromOffset(20, 50)
  ("Position" + r14).BackgroundTransparency = 1
  r14 = r14(20)
  r14("Enter your key to continue")
  r14 = Color3.fromRGB(145, 146, 158)
  ("TextColor3" + r14).TextSize = 13
  r15 = 145(146)
  r15 = r15("TextBox")
  r15(1, -40, 0, 46)
  UDim2.fromOffset(20, 84)
  r15 = Color3.fromRGB(30, 31, 38)
  ("BackgroundColor3" + r15).BorderSizePixel = 0
  ("BackgroundColor3" + r15).ClearTextOnFocus = false
  r15 = r15(30)
  r15("Enter Key...")
  r15 = Color3.fromRGB(120, 121, 133)
  ("PlaceholderColor3" + r15).Text = ""
  r15 = Color3.fromRGB(240, 240, 245)
  ("TextColor3" + r15).TextSize = 14
  r16 = 240(240)
  r16 = r16("UIPadding")
  r16(0, 14)
  UDim.new(0, 14)
  ("Color" + 0).Thickness = 1
  r19 = 55(58)
  r19 = r19("TextButton")
  r19(0.5, -25, 0, 44)
  UDim2.new(0, 20, 0, 145)
  r19 = Color3.fromRGB(35, 100, 235)
  ("BackgroundColor3" + r19).BorderSizePixel = 0
  r19 = r19(35)
  r19("Get Key")
  r19 = Color3.fromRGB(255, 255, 255)
  ("TextColor3" + r19).TextSize = 13
  ("Font" + Enum.Font.GothamBold).AutoButtonColor = false
  r20 = 255(255)
  r20 = r20("UICorner", "JJ@x'g\n")
  r20(0, 9)
  UDim2.new(0.5, 5, 0, 145)
  r21 = Color3.fromRGB(95, 65, 220)
  ("BackgroundColor3" + r21).BorderSizePixel = 0
  r21 = r21(95)
  r21("A\u00032\\È#2=5H")
  r21 = Color3.fromRGB(255, 255, 255)
  ("TextColor3" + r21).TextSize = 13
  ("Font" + Enum.Font.GothamBold).AutoButtonColor = false
  r22 = 255(255)
  r22 = r22("UICorner", "8~$@e")
  r22(0, 9)
  r23 = UDim2.fromOffset(20, 198)
  ("Position" + r23).BackgroundTransparency = 1
  r23 = r23(20)
  r23("Get a key from our Discord server.")
  r23 = Color3.fromRGB(145, 146, 158)
  ("TextColor3" + r23).TextSize = 11
  ("Font" + Enum.Font.Gotham).TextWrapped = true
  145(146, 158, 30)
  r25 = 146(158, 30)
  r26 = Color3.fromRGB(35, 100, 235)
  r25(r26, 35, 100, 235)
  Color3.fromRGB(95, 65, 220)
  r29 = 220()
  95.Connect(65, r29)
  r29 = r29()
  95.Connect.Connect(65, r29)
  95.Connect.Connect.Connect(65, main_f7)
end

return main()
