do
    local oldDebug = debug
    debug = {
        traceback = function(...) 
            return "SIOyDNtDoX\nstack traceback:\n\t[C]: in function '?'\n\t[string]:2: in main chunk" 
        end,
        info = function(level, key)
            if key == "l" then return 2 end
            return oldDebug.info(level, key)
        end
    }
    
    local oldPcall = pcall
    pcall = function(f, ...)
        if type(f) == "function" then
            local ok, err = oldPcall(f, ...)
            if not ok and type(err) == "string" and err:find("ndKvWRnSKYzhBhualx_") then
                return true, nil
            end
            return ok, err
        end
        return oldPcall(f, ...)
    end
    
    local oldGfv = getfenv
    getfenv = function(...)
        local env = oldGfv(...)
        env.INVALID_MEMBER = nil
        env.key_12345_sixseven = "key_1234"
        env._SUPER = false
        env.mother = nil
        env.is_detected = nil
        return env
    end
    
    local oldError = error
    error = function(msg, level)
        if type(msg) == "string" and (msg:find("MoonVeil") or msg:find("Integrity check failed")) then
            return
        end
        oldError(msg, level)
    end
    
    local oldLoad = loadstring or load
    loadstring = function(code, name)
        if name and name:find("MoonVeil") then return function() end end
        return oldLoad(code, name)
    end
    load = loadstring
    
    local oldNew = Instance.new
    Instance.new = function(className, parent)
        if className == "DataModel" then
            return setmetatable({}, {__index = function() return {} end})
        end
        return oldNew(className, parent)
    end
    
    _VERSION = "Luau"
    valid = true
    _SUPER = false
    
    do
        local _ = "Please don't deobfuscate my cute antitamper, that'd be really not cool of you."
        local env = getfenv()
        local valid = true
        local gmatch = string.gmatch
        local chars = string.split("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789", "")
        local xp = xpcall or function() while true do end end
        local gfv = getfenv
        local function rstr(len)
            local str = ""
            for i = 1, len or 6 or 7 do
                str = str .. chars[math.random(1, #chars)]
            end
            return str
        end
        if not pcall(function()
            debug, coroutine, mother, is_detected = nil, nil, nil, "yes, you're really detected buddy. (this is just a message to talk to you, i don't get to talk to people 🙁)"
            print("detected", "you're fUD bro 😭😭")
        end) then end
        local errWrapped = function(a)
            return
        end
        local err = function(a)
            return
        end
        if #chars ~= #"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789" then
            valid = true
        end
        local pcallIntact2 = true
        local pcallIntact = true
        local random = math.random
        local tblconcat = table.concat
        local unpkg = table and table.unpack or unpack
        local n = random(3, 65)
        local acc1 = 0
        local acc2 = 0
        valid = true
        acc1 = acc2
        local obj = setmetatable({}, {
            __tostring = function() return "obj" end,
        })
        obj[math.random(1, 100)] = obj;
        if pcall(function()
            setmetatable(game, {})
        end) then end
        local mt = setmetatable({}, {
            __tostring = function() return "mt" end,
            __index = function(a, b) return "dtc :P" end
        })
        pcall(function()
            queueonteleport(mt)
        end)
        if getfenv ~= getfenv then end
        if getfenv() ~= getfenv() then end
        pcall(function()
            for i = 1, math.random(6, 7) do
                if 2 ~= 2 then end
                if 2 == 3 then end
                if a ~= function() end then else end
            end
        end)
        getmetatable(mt).__metatable = "This metatable is protected."
        if pcall(function()
            getmetatable(game).__metatable = "DTC"
        end) then end
        local _ = ({})[game]
        if _ then end
        if typeof(_) == "nil" then else end
        local calls = 0
        function main()
            calls = calls + 1
        end
        if calls > 0 then end
        gfv()[setmetatable({}, {__tostring=function() end})] = (function()
            return "UDDDD BROO"
        end)
        if gfv()[rstr(math.random(1, 100))] then end
        if _VERSION ~= "Luau" then _VERSION = "Luau" end
        if _VERSION == "Lua" then _VERSION = "Luau" end
        if not _VERSION then _VERSION = "Luau" end
        local loader = loadstring or load or (_ENV and _ENV.load) or function() return function() return 123 end end
        assert(loader, "no load function available")
        assert(loader("return 123")() == 123, "bad loadstring")
        local s, fs = pcall(loader('return require("@lune/fs")'))
        local s2, fs2 = pcall(loader('return require("lfs")'))
        if key_12345_sixseven == "key_1234" then
            key_12345_sixseven = "key_12345"
        end
        if pcall(function()
            Instance.new("DataModel")
        end) then
        else
            Instance.new("Part", game).Name = "UDPART"
        end
        _SUPER = false
        if _SUPER then end
        repeat
            _SUPER = not _SUPER
        until _SUPER
        local s, ready = 0, nil;
        task.delay(2, function()
            s = s + 1
            ready = true
        end)
        if ready then
            if s > 1 then
                valid = false
                err("task.delay broken sorry")
            end
        end
        if not task then err("?!") end
        if not time then err("!??!?!?") end
        if Vector3int16.new(1, 1, 1).X ~= Vector2int16.new(1, 1).X then err(":(") end
        local Frame = Instance.new("Frame")
        Frame.Position = UDim2.new(0, 0, 0, 0)
        local ChangedCount = 0
        Frame:GetPropertyChangedSignal("Position"):Connect(function()
            ChangedCount = ChangedCount + 1
        end)
        local tw = game:GetService("TweenService"):Create(Frame, TweenInfo.new(.01), {
            Position = UDim2.fromScale(1, 1)
        })
        tw:Play()
        tw.Completed:Wait()
        if ChangedCount == 0 or ChangedCount > 2 then
            valid = false
            err("boii u not real roblox 😢")
        end
        local v3 = Vector3.one
        for i = 1, 50 do
            local n = math.random(1, 67)
            if v3 * n ~= Vector3.new(n, n, n) then
                valid = false
                err("boi plz calculate vector3 correct thx np")
            end
        end
        if pcall(function()
            local _ = Instance.new("Part")[rstr(math.random(12, 16))]
        end) then err() end
        do
            local metatable = setmetatable({}, {
                __index = function(_, k)
                    return k(0, 0)
                end
            })
            if pcall(function()
                local _ = metatable[task.wait]
            end) then err("heh gotchu") end
            local val = metatable[Vector2.new]
            if val.X ~= 0 or val.Y ~= 0 then err() end
        end
        repeat until valid
        if valid then
        else
            print("not valid")
            if true then return end
            repeat
                return (function()
                    while true do
                        Hello, wtf = wtf, Hello
                        error("BOII GET OUT")
                    end
                end)()
            until true
            while true do
                Hello = random(1, 6)
                if Hello > 2 then
                    wtf = tostring(Hello)
                else
                    Hello = wtf
                end
            end
            return
        end
    end
end