#!/bin/bash
# install-luau-dumper.sh

set -e

echo "📦 LuauDumper Installer for Termux/Ubuntu"
echo "=========================================="

# Install dependencies
echo "Installing dependencies..."
sudo apt update
sudo apt install -y wget curl unzip

# Install .NET SDK
echo "Installing .NET SDK..."
if ! command -v dotnet &> /dev/null; then
    wget https://dot.net/v1/dotnet-install.sh
    chmod +x dotnet-install.sh
    ./dotnet-install.sh --channel 8.0
    echo 'export PATH=$PATH:~/.dotnet' >> ~/.bashrc
    export PATH=$PATH:~/.dotnet
fi

# Create project
echo "Creating project..."
mkdir -p ~/LuauDumper
cd ~/LuauDumper

# Download source
echo "Downloading source code..."
wget -O Program.cs https://pastebin.com/raw/your-paste-id

# Or create manually
if [ ! -f "Program.cs" ]; then
    echo "Creating Program.cs manually..."
    cat > Program.cs << 'EOF'
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using MoonSharp.Interpreter;

namespace ScriptDumper
{
    public class LuauDumper
    {
        private class DumpContext
        {
            public List<string> Output { get; set; } = new List<string>();
            public Dictionary<object, string> Registry { get; set; } = new Dictionary<object, string>();
            public HashSet<string> UnusedHttp { get; set; } = new HashSet<string>();
            public int Counter { get; set; } = 0;
            public int Indent { get; set; } = 0;
            public int LoopThreshold => 5;
            public int MaxBlockSize => 20;
        }

        private DumpContext _context = new DumpContext();

        private string Pad() => new string(' ', _context.Indent * 4);
        private string NormalizeLine(string str) => Regex.Replace(str, "_[0-9]+", "_X");

        private void Emit(string line, bool log = false)
        {
            if (line != null)
            {
                _context.Output.Add(Pad() + line);
                int n = _context.Output.Count;
                if (n >= _context.LoopThreshold)
                {
                    for (int blockSize = 1; blockSize <= _context.MaxBlockSize; blockSize++)
                    {
                        if (n >= blockSize * _context.LoopThreshold)
                        {
                            bool isCycle = true;
                            for (int r = 1; r < _context.LoopThreshold; r++)
                            {
                                for (int i = 0; i < blockSize; i++)
                                {
                                    string currentLine = NormalizeLine(_context.Output[n - 1 - i]);
                                    string previousLine = NormalizeLine(_context.Output[n - 1 - i - (r * blockSize)]);
                                    if (currentLine != previousLine)
                                    {
                                        isCycle = false;
                                        break;
                                    }
                                }
                                if (!isCycle) break;
                            }
                            if (isCycle)
                            {
                                var block = new List<string>();
                                for (int i = blockSize - 1; i >= 0; i--)
                                    block.Add(_context.Output[n - 1 - i]);
                                for (int i = 0; i < blockSize * _context.LoopThreshold; i++)
                                    _context.Output.RemoveAt(_context.Output.Count - 1);
                                _context.Output.Add(Pad() + "while true do");
                                foreach (var l in block)
                                    _context.Output.Add("    " + l);
                                _context.Output.Add(Pad() + "end");
                                throw new Exception("LOOP_DETECTED");
                            }
                        }
                    }
                }
            }
            if (log && line != null)
                Console.WriteLine(_context.Output[_context.Output.Count - 1]);
        }

        private string Serialize(object v, int ind = 0, HashSet<object> seen = null)
        {
            seen = seen ?? new HashSet<object>();
            Type t = v?.GetType();

            if (v is string str)
            {
                return "\"" + str.Replace("\\", "\\\\").Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t").Replace("\"", "\\\"") + "\"";
            }
            else if (v is int || v is float || v is double || v is bool)
            {
                return v.ToString().ToLowerInvariant();
            }
            else if (v == null)
            {
                return "nil";
            }
            else if (v is Delegate)
            {
                return "function(...) end";
            }
            else if (v is Dictionary<object, object> dict)
            {
                if (_context.Registry.ContainsKey(v))
                    return _context.Registry[v];
                if (seen.Contains(v))
                    return "{...}";
                seen.Add(v);

                bool isArray = true;
                int maxKey = 0;
                foreach (var kvp in dict)
                {
                    if (!(kvp.Key is int) || (int)kvp.Key <= 0)
                    {
                        isArray = false;
                        break;
                    }
                    if ((int)kvp.Key > maxKey) maxKey = (int)kvp.Key;
                }

                if (isArray)
                {
                    var parts = new List<string>();
                    for (int i = 1; i <= maxKey; i++)
                    {
                        if (dict.ContainsKey(i))
                            parts.Add(Serialize(dict[i], ind, seen));
                        else
                            parts.Add("nil");
                    }
                    return "{" + string.Join(", ", parts) + "}";
                }
                else
                {
                    var parts = new List<string>();
                    string innerPad = new string(' ', (ind + 1) * 4);
                    bool empty = true;
                    foreach (var kvp in dict)
                    {
                        empty = false;
                        string key = (kvp.Key is string && Regex.IsMatch((string)kvp.Key, "^[a-zA-Z_][a-zA-Z0-9_]*$")) 
                            ? (string)kvp.Key 
                            : "[" + Serialize(kvp.Key, 0, seen) + "]";
                        string value = Serialize(kvp.Value, ind + 1, seen);
                        parts.Add(innerPad + key + " = " + value);
                    }
                    if (empty) return "{}";
                    return "{\n" + string.Join(",\n", parts) + "\n" + new string(' ', ind * 4) + "}";
                }
            }
            else
            {
                return _context.Registry.ContainsKey(v) ? _context.Registry[v] : v?.ToString() ?? "nil";
            }
        }

        private List<string> SerializeArgs(object[] args, int start = 1)
        {
            var outList = new List<string>();
            for (int i = start - 1; i < args.Length; i++)
                outList.Add(Serialize(args[i], _context.Indent));
            return outList;
        }

        private string NextVar(string prefix = null)
        {
            _context.Counter++;
            return (prefix ?? "var") + "_" + _context.Counter;
        }

        private HashSet<string> _colonMethods = new HashSet<string>
        {
            "HttpGet", "HttpGetAsync", "WaitForChild", "FindFirstChild",
            "FindFirstChildOfClass", "FindFirstChildWhichIsA", "GetService",
            "Connect", "Once", "Wait", "Clone", "Destroy", "Create",
            "Play", "Stop", "FireServer", "InvokeServer", "SetCore",
            "GetCore", "JSONEncode", "JSONDecode", "GetAsync", "PostAsync",
            "GetChildren", "GetDescendants", "IsA", "SetAttribute",
            "GetAttribute", "ClearAllChildren", "Remove", "RequestAsync",
            "Kick", "Ban", "Disconnect", "Fire", "Invoke",
            "BindToRenderStep", "UnbindFromRenderStep", "CreateWindow", "AddButton",
            "AddToggle", "AddSlider", "AddDropdown", "AddColorPicker", "MakeWindow",
            "AddTab", "AddSection", "AddLabel", "AddTextbox", "AddBind",
            "AddKeybind", "Init", "Build", "CreateSection", "CreateTab",
            "CreateSlider", "CreateButton", "CreateToggle", "AddParagraph",
            "MakeTab", "MakeSection", "GetPivot", "GetBoundingBox",
            "GetFullName", "IsDescendantOf", "FindFirstAncestor", "FindFirstAncestorOfClass",
            "GetPlayers", "GetPlayerByUserId", "SendKeyEvent", "SendMouseButtonEvent",
            "IsKeyDown", "IsMouseButtonPressed"
        };

        private HashSet<string> _voidMethods = new HashSet<string>
        {
            "Destroy", "Play", "Stop", "FireServer", "ClearAllChildren",
            "Remove", "Kick", "Ban", "Disconnect", "SetAttribute", "Fire",
            "CaptureFocus", "ReleaseFocus", "SetPrimaryPartCFrame", "BreakJoints",
            "PivotTo", "SendKeyEvent", "SendMouseButtonEvent"
        };

        private HashSet<string> _callbackMethods = new HashSet<string>
        {
            "Connect", "Once", "Activated", "MouseButton1Click", "MouseButton2Click",
            "MouseButton1Down", "MouseButton1Up", "MouseButton2Down", "MouseButton2Up",
            "FocusLost", "TouchTap", "InputBegan", "InputEnded", "InputChanged",
            "MouseEnter", "MouseLeave", "Changed", "OnClientEvent", "OnServerEvent",
            "RenderStepped", "Heartbeat", "Stepped", "Idled"
        };

        private HashSet<string> _dotcallMethods = new HashSet<string>
        {
            "fromRGB", "fromHSV", "fromHex", "lookAt", "Angles",
            "fromAxisAngle", "fromOrientation"
        };

        private object MakeProxy(string name, bool register)
        {
            // In C#, we'll use a DynamicObject or simple wrapper
            // For simplicity, using a dictionary-based approach
            var proxy = new ProxyObject(name, this);
            if (register)
                _context.Registry[proxy] = name;
            return proxy;
        }

        public class ProxyObject
        {
            private string _name;
            private LuauDumper _dumper;
            private Dictionary<string, object> _properties = new Dictionary<string, object>();

            public ProxyObject(string name, LuauDumper dumper)
            {
                _name = name;
                _dumper = dumper;
            }

            public object this[string key]
            {
                get
                {
                    if (_properties.ContainsKey(key))
                        return _properties[key];
                    
                    string path = _name;
                    string keyStr = key;
                    string newPath = path + (_dumper._colonMethods.Contains(keyStr) ? ":" : ".") + keyStr;
                    var p = _dumper.MakeProxy(newPath, false);
                    _dumper._context.Registry[p] = newPath;
                    return p;
                }
                set
                {
                    string path = _name;
                    _dumper.Emit(path + "." + key + " = " + _dumper.Serialize(value, _dumper._context.Indent), true);
                    _properties[key] = value;
                }
            }

            public object Call(params object[] args)
            {
                string fullPath = _name;
                var raw = args;
                var match = Regex.Match(fullPath, @"(.+)[%.:]([^%.:]+)$");
                string parent = match.Success ? match.Groups[1].Value : null;
                string method = match.Success ? match.Groups[2].Value : null;

                bool isColonCall = false;
                if (parent != null && args.Length > 0 && args[0] is ProxyObject && 
                    _dumper._context.Registry.ContainsKey(args[0]) && 
                    _dumper._context.Registry[args[0]] == parent)
                    isColonCall = true;

                var argList = new List<object>();
                int startIdx = isColonCall ? 1 : 0;
                for (int i = startIdx; i < args.Length; i++)
                    argList.Add(args[i]);
                var argStrs = _dumper.SerializeArgs(argList.ToArray());

                // Check for callback methods
                if (_dumper._callbackMethods.Contains(method) || 
                    _dumper._callbackMethods.Contains(Regex.Match(fullPath, @"[^.:]+$").Value))
                {
                    var callback = args.Length > 0 ? args[0] : (argList.Count > 0 ? argList[0] : null);
                    if (callback is Delegate del)
                    {
                        string varName = _dumper.NextVar("conn");
                        _dumper.Emit("local " + varName + " = " + fullPath + "(function(...))", true);
                        _dumper._context.Indent++;
                        // Execute callback with mock args
                        var mockArgs = new object[3];
                        for (int i = 0; i < 3; i++)
                            mockArgs[i] = _dumper.MakeProxy(_dumper.NextVar("arg"), false);
                        try { del.DynamicInvoke(mockArgs); } catch { }
                        _dumper._context.Indent--;
                        _dumper.Emit("end)", true);
                        var p = _dumper.MakeProxy(varName, false);
                        _dumper._context.Registry[p] = varName;
                        return p;
                    }
                }

                if (parent == null)
                {
                    string varName = _dumper.NextVar("result");
                    var serializedArgs = _dumper.SerializeArgs(args);
                    _dumper.Emit("local " + varName + " = " + fullPath + "(" + string.Join(", ", serializedArgs) + ")", true);
                    var p = _dumper.MakeProxy(varName, false);
                    _dumper._context.Registry[p] = varName;
                    return p;
                }

                string sep = _dumper._colonMethods.Contains(method) ? ":" : ".";
                string call = parent + sep + method;

                if (method == "new")
                {
                    string varName = _dumper.NextVar("inst");
                    _dumper.Emit("local " + varName + " = " + parent + ".new(" + string.Join(", ", argStrs) + ")", true);
                    var p = _dumper.MakeProxy(varName, false);
                    _dumper._context.Registry[p] = varName;
                    return p;
                }
                else if (_dumper._dotcallMethods.Contains(method))
                {
                    string varName = _dumper.NextVar("val");
                    _dumper.Emit("local " + varName + " = " + parent + "." + method + "(" + string.Join(", ", argStrs) + ")", true);
                    var p = _dumper.MakeProxy(varName, false);
                    _dumper._context.Registry[p] = varName;
                    return p;
                }
                else if (method == "GetService")
                {
                    string svc = argList.Count > 0 ? argList[0]?.ToString() : "";
                    string varName = _dumper.NextVar(svc.Length > 4 ? svc.Substring(0, 4).ToLower() : "svc");
                    _dumper.Emit("local " + varName + " = " + parent + ":GetService(" + _dumper.Serialize(svc, 0) + ")", true);
                    var p = _dumper.MakeProxy(varName, false);
                    _dumper._context.Registry[p] = varName;
                    return p;
                }
                else if (_dumper._voidMethods.Contains(method))
                {
                    _dumper.Emit(call + "(" + string.Join(", ", argStrs) + ")", true);
                }
                else
                {
                    string varName = _dumper.NextVar("r");
                    _dumper.Emit("local " + varName + " = " + call + "(" + string.Join(", ", argStrs) + ")", true);
                    if (method == "HttpGet" || method == "HttpGetAsync")
                        _dumper._context.UnusedHttp.Add(varName);

                    // Execute callbacks in tables
                    foreach (var arg in argList)
                    {
                        if (arg is Dictionary<object, object> dict)
                        {
                            object cb = null;
                            if (dict.ContainsKey("callback") && dict["callback"] is Delegate)
                                cb = dict["callback"];
                            else if (dict.ContainsKey("Callback") && dict["Callback"] is Delegate)
                                cb = dict["Callback"];
                            
                            if (cb is Delegate del)
                            {
                                _dumper._context.Indent++;
                                try { del.DynamicInvoke(true); } catch { }
                                _dumper._context.Indent--;
                            }
                        }
                    }

                    var p = _dumper.MakeProxy(varName, false);
                    _dumper._context.Registry[p] = varName;
                    return p;
                }

                return null;
            }

            public override string ToString()
            {
                return _dumper._context.Registry.ContainsKey(this) ? 
                    _dumper._context.Registry[this] : _name;
            }
        }

        private Func<object[], object> MockProxy(string name)
        {
            return args =>
            {
                var argStrs = SerializeArgs(args);
                string varName = NextVar(Regex.Match(name, @"[^\.]+$").Value.ToLower());
                Emit("local " + varName + " = " + name + "(" + string.Join(", ", argStrs) + ")", true);
                var p = MakeProxy(varName, false);
                _context.Registry[p] = varName;
                return p;
            };
        }

        private Action<object[]> MockVoid(string name)
        {
            return args =>
            {
                var argStrs = SerializeArgs(args);
                Emit(name + "(" + string.Join(", ", argStrs) + ")", true);
            };
        }

        private Func<object[], object> MockReturn(string name, object val)
        {
            return args =>
            {
                var argStrs = SerializeArgs(args);
                if (argStrs.Count > 0)
                    Emit("local _ = " + name + "(" + string.Join(", ", argStrs) + ")", true);
                else
                    Emit("local _ = " + name + "()", true);
                return val;
            };
        }

        private Dictionary<string, object> MakeLibrary(string name, Dictionary<string, object> predefined = null)
        {
            var lib = predefined ?? new Dictionary<string, object>();
            // Add indexer functionality
            return lib;
        }

        private Dictionary<string, object> BuildEnv()
        {
            var env = new Dictionary<string, object>();

            var robloxTypes = new[] { "Instance", "CFrame", "Vector3", "Vector2", "UDim", "UDim2", "Color3", "Rect", "Ray", "NumberRange", "PhysicalProperties", "TweenInfo", "OverlapParams", "RaycastParams", "Font", "Enum", "Enums", "BrickColor", "Region3", "PathWaypoint" };
            var robloxGlobals = new[] { "game", "workspace", "script", "plugin", "shared", "CoreGui", "Stats", "Lighting", "Players", "ReplicatedFirst", "ReplicatedStorage", "ServerScriptService", "ServerStorage", "StarterGui", "StarterPack", "StarterPlayer", "Teams", "SoundService", "Chat", "TextChatService" };

            foreach (var n in robloxTypes)
                env[n] = MakeProxy(n, true);
            foreach (var n in robloxGlobals)
                env[n] = MakeProxy(n, true);

            // Cache library
            var cacheLib = new Dictionary<string, object>
            {
                ["invalidate"] = MockVoid("cache.invalidate"),
                ["iscached"] = MockReturn("cache.iscached", true),
                ["replace"] = MockVoid("cache.replace")
            };
            env["cache"] = cacheLib;

            // Crypt library
            var cryptLib = new Dictionary<string, object>
            {
                ["base64encode"] = MockReturn("crypt.base64encode", "dW5j"),
                ["base64decode"] = MockReturn("crypt.base64decode", "unc"),
                ["encrypt"] = MockReturn("crypt.encrypt", "encrypted_data"),
                ["decrypt"] = MockReturn("crypt.decrypt", "decrypted_data"),
                ["generatebytes"] = MockReturn("crypt.generatebytes", "bytes"),
                ["generatekey"] = MockReturn("crypt.generatekey", "key"),
                ["hash"] = MockReturn("crypt.hash", "hash")
            };
            env["crypt"] = cryptLib;

            // HTTP library
            var httpLib = new Dictionary<string, object>
            {
                ["request"] = MockProxy("request")
            };
            env["http"] = httpLib;

            var proxyFns = new[] { "readfile", "getgc", "getinstances", "getnilinstances", "getscripts", "getconnections", "gethui", "getrawmetatable", "hookmetamethod", "hookfunction", "cloneref", "request", "getloadedmodules", "getreg", "getsenv", "getcallbackvalue", "getcustomasset", "gethiddenproperty", "getscripthash", "getcallstack", "getinputs", "getrunningscripts", "lz4compress", "lz4decompress", "listfiles", "getnamecallmethod", "rconsoleinput", "newcclosure", "loadfile", "getthreadidentity" };
            var voidFns = new[] { "writefile", "appendfile", "makefolder", "setthreadidentity", "rconsoleprint", "mouse1click", "keypress", "setclipboard", "fireclickdetector", "setfflag", "sethiddenproperty", "setrawmetatable", "setnamecallmethod", "setreadonly", "delfolder", "delfile", "setfpscap", "setrbxclipboard", "fireproximityprompt", "firetouchinterest", "rconsoleinfo", "rconsolewarn", "rconsoleerr", "rconsoleclear", "rconsolename", "mouse1press", "mouse1release", "mouse2click", "mouse2press", "mouse2release", "mousescroll", "mousemoverel", "mousemoveabs", "keyrelease" };
            var trueFns = new[] { "isfile", "isfolder", "checkcaller", "isrbxactive", "getfflag", "getfflags", "isfflagenabled", "checkclosure", "islclosure", "iscclosure", "isreadonly", "isnetworkowner", "compareinstances" };

            foreach (var name in proxyFns)
                env[name] = MockProxy(name);
            foreach (var name in voidFns)
                env[name] = MockVoid(name);
            foreach (var name in trueFns)
                env[name] = MockReturn(name, true);

            // Identify executor
            env["identifyexecutor"] = new Func<object[]>(() =>
            {
                Emit("local exec_name, exec_ver = identifyexecutor()", true);
                return new object[] { "MimicDumper", "2.0" };
            });

            env["getgenv"] = new Func<object>(() => env);
            env["getrenv"] = new Func<object>(() => env);
            env["_G"] = env;

            env["print"] = new Action<object[]>((args) =>
            {
                Emit("print(" + string.Join(", ", SerializeArgs(args)) + ")", true);
            });

            env["warn"] = new Action<object[]>((args) =>
            {
                Emit("warn(" + string.Join(", ", SerializeArgs(args)) + ")", true);
            });

            // Task library
            var taskLib = new Dictionary<string, object>
            {
                ["wait"] = new Func<object, double>((n) => { Emit("task.wait(" + Serialize(n, 0) + ")", true); return 0; }),
                ["spawn"] = new Action<Delegate, object[]>((f, args) => 
                { 
                    Emit("task.spawn(function())", true); 
                    _context.Indent++; 
                    try { f?.DynamicInvoke(args); } catch { } 
                    _context.Indent--; 
                    Emit("end)", true); 
                }),
                ["defer"] = new Action<Delegate, object[]>((f, args) => 
                { 
                    Emit("task.defer(function())", true); 
                    _context.Indent++; 
                    try { f?.DynamicInvoke(args); } catch { } 
                    _context.Indent--; 
                    Emit("end)", true); 
                }),
                ["delay"] = new Action<object, Delegate, object[]>((n, f, args) => 
                { 
                    Emit("task.delay(" + Serialize(n, 0) + ", function())", true); 
                    _context.Indent++; 
                    try { f?.DynamicInvoke(args); } catch { } 
                    _context.Indent--; 
                    Emit("end)", true); 
                })
            };
            env["task"] = taskLib;

            env["require"] = new Func<object, object>((module) =>
            {
                string varName = NextVar("module");
                Emit("local " + varName + " = require(" + Serialize(module, 0) + ")", true);
                var p = MakeProxy(varName, false);
                _context.Registry[p] = varName;
                return p;
            });

            env["loadstring"] = new Func<object, object, Func<object[], object>>((src, chunkname) =>
            {
                string argStr = _context.Registry.ContainsKey(src) ? _context.Registry[src] : null;
                if (argStr != null && _context.UnusedHttp.Contains(argStr))
                    _context.UnusedHttp.Remove(argStr);
                string varName = NextVar("loaded");
                Emit("local " + varName + " = loadstring(" + Serialize(src, 0) + (chunkname != null ? (", " + Serialize(chunkname, 0)) : "") + ")", true);
                return (args) =>
                {
                    var argStrs = SerializeArgs(args);
                    string retVar = NextVar("chunk_res");
                    Emit("local " + retVar + " = " + varName + "(" + string.Join(", ", argStrs) + ")", true);
                    var p = MakeProxy(retVar, false);
                    _context.Registry[p] = retVar;
                    return p;
                };
            });

            return env;
        }

        public bool Run(string input, string output = null)
        {
            output = output ?? "output.lua";
            if (!File.Exists(input))
            {
                Console.WriteLine("[!] Failed to read: " + input);
                return false;
            }

            string source = File.ReadAllText(input);
            _context = new DumpContext();
            Emit("-- Generated by 45ms discord.gg/4H6wAW7mx7", false);
            var env = BuildEnv();

            try
            {
                // Execute the Lua code
                var script = new Script();
                foreach (var kvp in env)
                    script.Globals[kvp.Key] = kvp.Value;
                script.DoString(source);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[!] Runtime error: " + ex.Message);
                return false;
            }

            foreach (string httpVar in _context.UnusedHttp)
                Emit("loadstring(" + httpVar + ")()", true);

            File.WriteAllText(output, string.Join("\n", _context.Output));
            Console.WriteLine("[*] Saved to: " + output);
            return true;
        }

        public static void Main(string[] args)
        {
            var dumper = new LuauDumper();
            if (args.Length >= 1)
                dumper.Run(args[0], args.Length >= 2 ? args[1] : null);
            else
                Console.WriteLine("Usage: LuauDumper <input> [output]");
        }
    }
}
EOF
fi

# Create project file
if [ ! -f "LuauDumper.csproj" ]; then
    dotnet new console
    dotnet add package MoonSharp.Interpreter
fi

# Build
echo "Building..."
dotnet build -c Release

echo ""
echo "✅ Installation complete!"
echo ""
echo "Usage:"
echo "  cd ~/LuauDumper"
echo "  dotnet run -- script.lua"
echo "  dotnet run -- script.lua output.lua"
echo ""
echo "Or run directly:"
echo "  dotnet bin/Release/net8.0/LuauDumper.dll script.lua"