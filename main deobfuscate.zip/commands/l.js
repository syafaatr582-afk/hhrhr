const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getInputContent, extractCode } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');
const { runLune } = require('../utils/runner');
const { uploadToPasteCNet } = require('../utils/upload');

module.exports = {
    name: 'l',
    aliases: ['dump', 'env'],
    async execute(message, args) {
        let targetMessage = message;
        if (message.reference) {
            try {
                targetMessage = await message.fetchReference();
            } catch (e) {
                console.error('failed to fetch reference:', e.message);
            }
        }

        const arg = args.join(' ');
        const hasAttachment = targetMessage.attachments && targetMessage.attachments.size > 0;
        const hasContent = (targetMessage.content && targetMessage.content.trim().length > 0);
        const hasArg = arg.length > 0;

        if (!hasArg && !hasAttachment && !hasContent) {
            return message.reply(
                '❌ error: please provide input\n\n' +
                '📌 usage:\n.l <url>\n.l (reply)\n.l (attach file)\n.l <code>'
            );
        }

        const statusMsg = await message.reply('processing input...');
        try {
            let input;
            if (message.reference && targetMessage.id !== message.id) {
                input = await getInputContent(targetMessage, '');
                if (!input && hasArg) {
                    input = await getInputContent(message, arg);
                }
            } else {
                input = await getInputContent(message, arg);
            }

            if (!input) return statusMsg.edit('❌ error: could not extract content');

            const extracted = extractCode(input);
            if (!extracted) return statusMsg.edit('❌ error: could not extract valid code');

            const tempDir = os.tmpdir();
            const inputPath = path.join(tempDir, `input_${Date.now()}.lua`);
            const outputPath = path.join(tempDir, `output_${Date.now()}.lua`);
            fs.writeFileSync(inputPath, extracted, 'utf-8');

            await statusMsg.edit('running Mylie...');
            const result = await runLune('mylie.luau', inputPath, outputPath, 'MYLIE');
            if (result.error) return statusMsg.edit(`❌ error: ${result.error}`);
            if (!fs.existsSync(outputPath)) return statusMsg.edit('❌ error: output not found');

            let output = fs.readFileSync(outputPath, 'utf-8');
            if (!output.trim()) return statusMsg.edit('Mylie result is empty');
            output = addWatermark(output);

            const outFilename = generateRandomFilename();
            const outFile = path.join(tempDir, outFilename);
            fs.writeFileSync(outFile, output, 'utf-8');

            const preview = output.slice(0, 1000) + (output.length > 1000 ? '\n... (truncated)' : '');

            await statusMsg.edit('running Mylie...');

            let uploadUrl = null;
            try {
                const u = await uploadToPasteCNet(outFile);
                if (u && u.success) uploadUrl = u.url;
            } catch (e) {
                console.error('upload failed:', e.message);
            }

            const embed = new EmbedBuilder()
                .setTitle('✅ Mylie Successful')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x00ff00)
                .addFields(
                    { name: '📊 Size', value: `${output.length} chars`, inline: true },
                    { name: '⏱️ Time', value: `${result.time}ms`, inline: true },
                    { name: '👤 User', value: message.author.toString(), inline: true }
                );

            if (uploadUrl) {
                embed.addFields(
                    { name: '🔗 Link', value: `[Click Here](${uploadUrl})`, inline: false }
                );
                embed.setFooter({ text: 'Mylie by oweeee dumper | paste.c-net.org' });
            } else {
                embed.setFooter({ text: 'Mylie by oweeee dumper' });
            }

            const contentText = uploadUrl
                ? `✅ Mylie successful! [View Output](${uploadUrl})`
                : '✅ Mylie successful (upload failed, sent as attachment)';

            await statusMsg.edit({
                content: contentText,
                embeds: [embed],
                files: [new AttachmentBuilder(outFile, { name: outFilename })]
            });

            try { fs.unlinkSync(inputPath); fs.unlinkSync(outputPath); fs.unlinkSync(outFile); } catch (e) {}

        } catch (error) {
            console.error('l error:', error);
            await statusMsg.edit(`error: ${error.message.slice(0, 1000)}`);
        }
    }
};