const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getInputContent, extractCode } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');
const { runPython } = require('../utils/runner');
const { PATHS } = require('../config');

module.exports = {
    name: 'rename',
    aliases: ['rn', 'rm'],
    async execute(message, args) {
        const arg = args.join(' ');
        if (!arg && !message.attachments.size && !message.reference) {
            return message.reply(
                '❌ error: please provide input\n\n' +
                '📌 usage:\n' +
                '.rename <url>\n' +
                '.rename (reply)\n' +
                '.rename (attach file)\n' +
                '.rename <direct code>'
            );
        }

        const statusMsg = await message.reply('🔄 processing input for luaurenamer...');

        const tempDir = os.tmpdir();
        const inputPath = path.join(tempDir, `rename_input_${Date.now()}.lua`);
        const outputPath = path.join(tempDir, `rename_output_${Date.now()}.lua`);

        try {
            // 1) ambil raw input
            const rawInput = await getInputContent(message, arg);
            if (!rawInput) return statusMsg.edit('❌ error: could not extract content');

            // 2) unwrap codeblock / loadstring / base64
            const extracted = extractCode(rawInput);
            if (!extracted) return statusMsg.edit('❌ error: could not extract valid code');

            fs.writeFileSync(inputPath, extracted, 'utf-8');

            await statusMsg.edit('⏳ running luaurenamer...');

            // 3) spawn: python luaurenamer.py <input> <output>
            const result = await runPython(
                PATHS.LUAURENAMER_SCRIPT,
                [inputPath, outputPath],
                'LUAURENAMER'
            );

            if (result.error) return statusMsg.edit(`❌ error: ${result.error}`);
            if (!fs.existsSync(outputPath)) return statusMsg.edit('❌ error: output file not found');

            let outputContent = fs.readFileSync(outputPath, 'utf-8');
            if (!outputContent || !outputContent.trim()) {
                return statusMsg.edit('❌ luaurenamer result is empty');
            }

            outputContent = addWatermark(outputContent);

            const outFilename = generateRandomFilename();
            const outFile = path.join(tempDir, outFilename);
            fs.writeFileSync(outFile, outputContent, 'utf-8');

            const preview = outputContent.slice(0, 1000) + (outputContent.length > 1000 ? '\n... (truncated)' : '');

            const embed = new EmbedBuilder()
                .setTitle('✅ Rename Successful')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x9B59B6)
                .addFields(
                    { name: '📊 Size', value: `${outputContent.length} chars`, inline: true },
                    { name: '⏱️ Time', value: `${result.time}ms`, inline: true },
                    { name: '👤 User', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: '🔧 processed by luaurenamer.py' });

            await statusMsg.edit({
                content: '✅ rename successful',
                embeds: [embed],
                files: [new AttachmentBuilder(outFile, { name: outFilename })]
            });

            try {
                fs.unlinkSync(inputPath);
                if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
                fs.unlinkSync(outFile);
            } catch (e) {}

        } catch (error) {
            console.error('error in rename command:', error);
            try {
                await statusMsg.edit(`❌ error: ${error.message.slice(0, 1000)}`);
            } catch (e) {
                await message.reply(`❌ error: ${error.message.slice(0, 1000)}`);
            }
        }
    }
};