const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { resolveInput } = require('../utils/input');
const { addWatermark, generateRandomFilename, findLatestOutFile } = require('../utils/files');
const { runPython } = require('../utils/runner');
const { PATHS } = require('../config');

module.exports = {
    name: 'herdeobf',
    aliases: ['herculesdeobf'],
    async execute(message, args) {
        // parse mode flags
        let mode = null;
        let inputArgs = args;
        if (args.length > 0) {
            if (args[0] === '--dis') { mode = 'disassembly'; inputArgs = args.slice(1); }
            else if (args[0] === '--b') { mode = 'both'; inputArgs = args.slice(1); }
        }

        const { content, error } = await resolveInput(message, inputArgs);
        if (error || !content) return message.reply(error || 'please provide input.');

        const statusMsg = await message.reply(`⏳ running Hercules deobfuscator${mode ? ` (${mode})` : ''}...`);
        const tempDir = os.tmpdir();
        const inputPath = path.join(tempDir, `hercules_input_${Date.now()}.lua`);
        const outputPath = path.join(tempDir, `hercules_output_${Date.now()}.lua`);

        try {
            fs.writeFileSync(inputPath, content);

            const pyArgs = [PATHS.HERCULES_SCRIPT, inputPath, outputPath];
            if (mode) pyArgs.push('--mode', mode);

            const result = await runPython(pyArgs[0], pyArgs.slice(1), 'HERCULES');
            if (result.error) return statusMsg.edit(`❌ error: ${result.error}`);

            let outputContent = null;
            if (fs.existsSync(outputPath)) outputContent = fs.readFileSync(outputPath, 'utf-8');
            if (!outputContent) {
                const latest = findLatestOutFile();
                if (latest) outputContent = fs.readFileSync(latest.path, 'utf-8');
            }
            if (!outputContent) return statusMsg.edit('❌ Hercules result is empty');

            outputContent = addWatermark(outputContent);
            const outFilename = generateRandomFilename();
            const outFile = path.join(tempDir, outFilename);
            fs.writeFileSync(outFile, outputContent, 'utf-8');

            const preview = outputContent.slice(0, 1000) + (outputContent.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('🦁 Hercules Deobfuscator Successful')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0xF5A623)
                .addFields(
                    { name: '📊 size', value: `${outputContent.length} chars`, inline: true },
                    { name: '⏱️ time', value: `${result.time}ms`, inline: true },
                    { name: '👤 user', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: `deobfuscated by Hercules${mode ? ` (${mode})` : ''}` });

            await statusMsg.edit({
                content: '✅ Hercules deobfuscation successful',
                embeds: [embed],
                files: [new AttachmentBuilder(outFile, { name: outFilename })]
            });

            try {
                fs.unlinkSync(outFile);
                fs.unlinkSync(inputPath);
                if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
            } catch (e) {}
        } catch (error) {
            console.error('hercules error:', error);
            await statusMsg.edit(`❌ error: ${error.message.slice(0, 1000)}`);
        }
    }
};