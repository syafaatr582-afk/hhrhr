const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getInputContent } = require('../utils/input');
const { addWatermark, generateRandomFilename, findLatestOutFile } = require('../utils/files');
const { runLune } = require('../utils/runner');
const { PATHS } = require('../config');

module.exports = {
    name: '45ms',
    aliases: ['45'],
    async execute(message, args) {
        const arg = args.join(' ');
        if (!arg && !message.attachments.size && !message.reference) {
            return message.reply('❌ error: please provide input\n\n📌 usage:\n.45ms <url> | (reply) | (attach) | <code>');
        }
        const statusMsg = await message.reply('🔄 processing input for 45ms...');
        try {
            const inputContent = await getInputContent(message, arg);
            if (!inputContent) return statusMsg.edit('❌ error: could not extract content');

            const tempDir = os.tmpdir();
            const inputPath = path.join(tempDir, `45ms_input_${Date.now()}.lua`);
            const outputPath = path.join(tempDir, `45ms_output_${Date.now()}.lua`);
            fs.writeFileSync(inputPath, inputContent, 'utf-8');

            const result = await runLune(PATHS.FORTYFIVE_SCRIPT, inputPath, outputPath, '45MS');
            if (result.error) return statusMsg.edit(`❌ error: ${result.error}`);

            let outputContent = null;
            if (fs.existsSync(outputPath)) outputContent = fs.readFileSync(outputPath, 'utf-8');
            if (!outputContent) {
                const latest = findLatestOutFile();
                if (latest) outputContent = fs.readFileSync(latest.path, 'utf-8');
            }
            if (!outputContent) return statusMsg.edit('❌ 45ms result is empty');

            outputContent = addWatermark(outputContent);
            const outFilename = generateRandomFilename();
            const outFile = path.join(tempDir, outFilename);
            fs.writeFileSync(outFile, outputContent, 'utf-8');

            const preview = outputContent.slice(0, 1000) + (outputContent.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('⚡ 45ms Successful')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0xFF4500)
                .addFields(
                    { name: '📊 size', value: `${outputContent.length} chars`, inline: true },
                    { name: '⏱️ time', value: `${result.time}ms`, inline: true },
                    { name: '👤 user', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: '⚡ processed by 45ms' });

            await statusMsg.edit({
                content: '✅ 45ms processing successful',
                embeds: [embed],
                files: [new AttachmentBuilder(outFile, { name: outFilename })]
            });

            try { fs.unlinkSync(inputPath); fs.unlinkSync(outputPath); fs.unlinkSync(outFile); } catch (e) {}
        } catch (error) {
            console.error('45ms error:', error);
            await statusMsg.edit(`❌ error: ${error.message.slice(0, 1000)}`);
        }
    }
};