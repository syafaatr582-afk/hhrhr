const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { resolveInput } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');
const { runProcess } = require('../utils/runner');

module.exports = {
    name: 'ironveil',
    aliases: ['iv'],
    async execute(message, args) {
        const { content, error } = await resolveInput(message, args);
        if (error || !content) return message.reply(error || 'please provide input.');

        const statusMsg = await message.reply('running ironveil deobfuscator...');
        const tempDir = os.tmpdir();
        const tempFile = path.join(tempDir, `iv_input_${Date.now()}.lua`);
        const outFile = path.join(tempDir, `iv_output_${Date.now()}.lua`);

        try {
            fs.writeFileSync(tempFile, content);

            const result = await runProcess('node', ['./deobf/index.js', tempFile, outFile], 'IRONVEIL', 60000);
            if (result.error) return statusMsg.edit(`❌ error: ${result.error}`);
            if (!fs.existsSync(outFile)) return statusMsg.edit('❌ error: output file not found');

            let code = fs.readFileSync(outFile, 'utf-8');
            if (!code.trim()) return statusMsg.edit('❌ error: no deobfuscated code');
            code = addWatermark(code);

            const outFilename = generateRandomFilename();
            const finalOut = path.join(tempDir, outFilename);
            fs.writeFileSync(finalOut, code, 'utf-8');

            const preview = code.slice(0, 1000) + (code.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('ironveil deobfuscated')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x00ff00)
                .addFields(
                    { name: 'size', value: `${(code.length / 1024).toFixed(2)} kb`, inline: true },
                    { name: 'user', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: 'deobfuscated by ironveil' });

            await statusMsg.edit({
                content: 'ironveil deobfuscation complete',
                embeds: [embed],
                files: [new AttachmentBuilder(finalOut, { name: outFilename })]
            });

            try { fs.unlinkSync(tempFile); fs.unlinkSync(outFile); fs.unlinkSync(finalOut); } catch (e) {}
        } catch (error) {
            console.error('ironveil error:', error);
            await statusMsg.edit(`❌ error: ${error.message}`);
        }
    }
};