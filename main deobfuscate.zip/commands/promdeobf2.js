const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { resolveInput } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');
const { runProcess } = require('../utils/runner');
const { uploadWithCurl } = require('../utils/upload');

module.exports = {
    name: 'promdeobf2',
    aliases: ['prom2', 'p2', 'wd2'],
    async execute(message, args) {
        const { content, error } = await resolveInput(message, args);
        if (error || !content) return message.reply(error || 'please provide input.');

        const statusMsg = await message.reply('🔄 running prometheus deobfuscator v2...');
        const tempDir = os.tmpdir();
        const inputPath = path.join(tempDir, `prom2_input_${Date.now()}.lua`);
        const outputPath = path.join(tempDir, `prom2_output_${Date.now()}.lua`);

        try {
            fs.writeFileSync(inputPath, content);

            const result = await runProcess(
                'node',
                ['./prom/bin/pdeobf.js', inputPath, '-o', outputPath, '--force', '--fast', '-q'],
                'PROM2',
                60000
            );

            if (result.error) return statusMsg.edit(`❌ error: ${result.error}`);
            if (!fs.existsSync(outputPath)) return statusMsg.edit('❌ error: output file not found');

            let code = fs.readFileSync(outputPath, 'utf-8');
            if (!code || !code.trim()) return statusMsg.edit('❌ error: no deobfuscated code');

            code = addWatermark(code);
            const outFilename = generateRandomFilename();
            const outFile = path.join(tempDir, outFilename);
            fs.writeFileSync(outFile, code, 'utf-8');

            // try upload
            let uploadUrl = null;
            try {
                const u = await uploadWithCurl(outFile);
                if (u && u.success) uploadUrl = u.url;
            } catch (e) {}

            const preview = code.slice(0, 1000) + (code.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('✅ prometheus v2 deobfuscated')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x00ff00)
                .addFields(
                    { name: '📊 size', value: `${(code.length / 1024).toFixed(2)} kb`, inline: true },
                    { name: '👤 user', value: message.author.toString(), inline: true }
                );

            if (uploadUrl) {
                embed.addFields({ name: '🔗 link', value: `[click here](${uploadUrl})`, inline: true });
                embed.setFooter({ text: 'prometheus v2 | paste.c-net.org' });
                await statusMsg.edit({
                    content: `✅ prometheus v2 deobfuscation complete! [view output](${uploadUrl})`,
                    embeds: [embed]
                });
            } else {
                embed.setFooter({ text: 'prometheus v2 (attachment)' });
                await statusMsg.edit({
                    content: '✅ prometheus v2 deobfuscation complete (attachment)',
                    embeds: [embed],
                    files: [new AttachmentBuilder(outFile, { name: outFilename })]
                });
            }

            try { fs.unlinkSync(inputPath); fs.unlinkSync(outputPath); fs.unlinkSync(outFile); } catch (e) {}
        } catch (error) {
            console.error('prom2 error:', error);
            await statusMsg.edit(`❌ error: ${error.message}`);
        }
    }
};