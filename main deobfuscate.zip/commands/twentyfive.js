const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { getInputContent, extractCode } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');
const { runLune } = require('../utils/runner');
const { PATHS } = require('../config');

module.exports = {
    name: '25ms',
    aliases: ['25ms', '25', '2'],
    async execute(message, args) {
        const arg = args.join(' ');
        if (!arg && !message.attachments.size && !message.reference) {
            return message.reply(
                '❌ error: please provide input\n\n' +
                '📌 usage:\n' +
                '.25ms <url>\n' +
                '.25ms (reply to codeblock)\n' +
                '.25ms (with .txt/.lua file attached)\n' +
                '.25ms <direct code>'
            );
        }

        const statusMsg = await message.reply('🔄 processing input for 25ms dumper...');

        const tempDir = os.tmpdir();
        const inputPath = path.join(tempDir, `25ms_input_${Date.now()}.lua`);
        const outputPath = path.join(tempDir, `25ms_output_${Date.now()}.lua`);

        try {
            const rawInput = await getInputContent(message, arg);
            if (!rawInput) return statusMsg.edit('❌ error: could not extract content');

            const extracted = extractCode(rawInput);
            if (!extracted) return statusMsg.edit('❌ error: could not extract valid code');

            fs.writeFileSync(inputPath, extracted, 'utf-8');

            await statusMsg.edit('⏳ running 25ms dumper...');

            const result = await runLune(PATHS.TWENTYFIVE_SCRIPT, inputPath, outputPath, '25MS');
            if (result.error) return statusMsg.edit(`❌ error: ${result.error}`);
            if (!fs.existsSync(outputPath)) return statusMsg.edit('❌ error: output file not found');

            let outputContent = fs.readFileSync(outputPath, 'utf-8');
            if (!outputContent || !outputContent.trim()) {
                return statusMsg.edit('❌ 25ms dump result is empty');
            }

            outputContent = addWatermark(outputContent);

            const outFilename = generateRandomFilename();
            const outFile = path.join(tempDir, outFilename);
            fs.writeFileSync(outFile, outputContent, 'utf-8');

            const preview = outputContent.slice(0, 1000) + (outputContent.length > 1000 ? '\n... (truncated)' : '');

            const embed = new EmbedBuilder()
                .setTitle('✅ 25ms Dump Successful')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x00CED1)
                .addFields(
                    { name: '📊 Size', value: `${outputContent.length} chars`, inline: true },
                    { name: '⏱️ Time', value: `${result.time}ms`, inline: true },
                    { name: '👤 User', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: '25ms dumper (httplog2.lua)' });

            await statusMsg.edit({
                content: '✅ 25ms dump successful',
                embeds: [embed],
                files: [new AttachmentBuilder(outFile, { name: outFilename })]
            });

            try {
                fs.unlinkSync(inputPath);
                fs.unlinkSync(outputPath);
                fs.unlinkSync(outFile);
            } catch (e) {}

        } catch (error) {
            console.error('error in 25ms command:', error);
            try {
                await statusMsg.edit(`❌ error: ${error.message.slice(0, 1000)}`);
            } catch (e) {
                await message.reply(`❌ error: ${error.message.slice(0, 1000)}`);
            }
        }
    }
};