const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { resolveInput } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');

function removeComments(code) {
    if (!code) return code;
    let result = '', i = 0;
    let inString = false, stringChar = '', inLongComment = false, inLongString = false;

    while (i < code.length) {
        if (!inLongComment && !inLongString) {
            if ((code[i] === '"' || code[i] === "'") && (i === 0 || code[i-1] !== '\\')) {
                if (!inString) { inString = true; stringChar = code[i]; result += code[i]; i++; continue; }
                else if (code[i] === stringChar) { inString = false; result += code[i]; i++; continue; }
            }
        }
        if (inString) { result += code[i]; i++; continue; }

        if (!inLongComment && !inLongString) {
            if (code[i] === '[' && i+1 < code.length && code[i+1] === '[') {
                let j = i + 2, equals = 0;
                while (j < code.length && code[j] === '=') { equals++; j++; }
                if (j < code.length && code[j] === '[') { inLongString = true; result += code[i] + code[i+1]; i += 2; continue; }
            }
        }
        if (inLongString) {
            result += code[i]; i++;
            if (code[i-1] === ']' && i < code.length) {
                let j = i, equals = 0;
                while (j < code.length && code[j] === '=') { equals++; j++; }
                if (j < code.length && code[j] === ']') { inLongString = false; result += code[i]; i++; }
            }
            continue;
        }
        if (!inLongComment && code[i] === '-' && i+1 < code.length && code[i+1] === '-') {
            if (i+2 < code.length && code[i+2] === '[') {
                let j = i + 3, equals = 0;
                while (j < code.length && code[j] === '=') { equals++; j++; }
                if (j < code.length && code[j] === '[') {
                    inLongComment = true; i += 3;
                    while (i < code.length && code[i] === '=') i++;
                    if (i < code.length && code[i] === '[') i++;
                    continue;
                }
            }
            while (i < code.length && code[i] !== '\n') i++;
            if (i < code.length && code[i] === '\n') { result += '\n'; i++; }
            continue;
        }
        if (inLongComment) {
            if (code[i] === ']' && i+1 < code.length && code[i+1] === ']') {
                let j = i + 2, equals = 0;
                while (j < code.length && code[j] === '=') { equals++; j++; }
                inLongComment = false; i += 2;
                while (i < code.length && code[i] === '=') i++;
                continue;
            }
            i++; continue;
        }
        result += code[i]; i++;
    }
    result = result.replace(/\n\s*\n/g, '\n\n').replace(/^\s+|\s+$/g, '');
    return result;
}

function hasComments(code) {
    if (!code) return false;
    if (code.match(/--[^[\n]/g)) return true;
    if (code.match(/--\[\[[\s\S]*?\]\]/g)) return true;
    return false;
}

module.exports = {
    name: 'rc',
    aliases: ['removecomment'],
    async execute(message, args) {
        const { content, error } = await resolveInput(message, args);
        if (error || !content) return message.reply(error || 'please provide input.');

        const statusMsg = await message.reply('🔄 removing comments...');
        try {
            const code = content.toString('utf-8');
            if (!hasComments(code)) return statusMsg.edit('ℹ️ no comments found in the script');

            let cleaned = removeComments(code);
            if (!cleaned || cleaned.trim() === '') return statusMsg.edit('❌ error: failed to remove comments');
            cleaned = addWatermark(cleaned);

            const outFilename = generateRandomFilename();
            const outFile = path.join(os.tmpdir(), outFilename);
            fs.writeFileSync(outFile, cleaned, 'utf-8');

            const preview = cleaned.slice(0, 1000) + (cleaned.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('✅ Comments Removed')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x00ff00)
                .addFields(
                    { name: '📊 size', value: `${(cleaned.length / 1024).toFixed(2)} kb`, inline: true },
                    { name: '📉 removed', value: `${((code.length - cleaned.length) / 1024).toFixed(2)} kb`, inline: true },
                    { name: '👤 user', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: '🔧 comments removed' });

            await statusMsg.edit({
                content: '✅ comments removed successfully',
                embeds: [embed],
                files: [new AttachmentBuilder(outFile, { name: outFilename })]
            });

            try { fs.unlinkSync(outFile); } catch (e) {}
        } catch (error) {
            console.error('removecomment error:', error);
            await statusMsg.edit(`❌ error: ${error.message}`);
        }
    }
};