const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { MAX_FILE_SIZE } = require('../config');

module.exports = {
    name: 'get',
    aliases: ['fetch', 'g', 'f'],
    async execute(message, args) {
        if (!args.length) return message.reply('❌ error: please provide a URL\n\n📌 usage:\n.get <url>');

        const url = args[0];
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            return message.reply('❌ error: invalid URL. Must start with http:// or https://');
        }

        const statusMsg = await message.reply('📥 fetching Lua script from URL...');

        try {
            const response = await axios.get(url, {
                responseType: 'text',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Roblox/WinInet',
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate',
                    'Connection': 'keep-alive',
                    'Cache-Control': 'no-cache'
                },
                maxRedirects: 10
            });

            let content = response.data;
            let filename = path.basename(url) || 'script.lua';
            if (!content || content.length === 0) return statusMsg.edit('❌ error: URL returned empty content');
            if (content.length > MAX_FILE_SIZE) return statusMsg.edit(`❌ error: content too large`);

            if (!content.includes('function') && !content.includes('local') && !content.includes('end')) {
                return statusMsg.edit('❌ error: URL does not contain Lua code');
            }

            const isObfuscated =
                content.includes('loadstring') || content.includes('string.char') ||
                content.includes('string.gsub') || content.includes('string.byte') ||
                content.includes('_G') || content.includes('getfenv') ||
                content.includes('setfenv') || content.includes('debug.getinfo');

            if (!filename.includes('.lua') && !filename.includes('.luau')) filename += '.lua';

            const tempFile = path.join(os.tmpdir(), `get_${Date.now()}_${filename}`);
            fs.writeFileSync(tempFile, content, 'utf-8');

            const preview = content.slice(0, 1000) + (content.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('📥 Lua Script Fetched')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(isObfuscated ? 0xFF0000 : 0x00BFFF)
                .addFields(
                    { name: '📊 Size', value: `${(content.length / 1024).toFixed(2)} KB`, inline: true },
                    { name: '🔗 URL', value: `${url.length > 40 ? url.slice(0, 40) + '...' : url}`, inline: true },
                    { name: '👤 User', value: message.author.toString(), inline: true }
                );

            if (isObfuscated) embed.addFields({ name: '⚠️ Obfuscated', value: 'Script appears to be obfuscated', inline: true });

            embed.setFooter({ text: '📥 fetched by Roblox client' }).setTimestamp();

            await statusMsg.edit({
                content: '✅ Lua script fetched successfully' + (isObfuscated ? ' | ⚠️ Detected obfuscation' : ''),
                embeds: [embed],
                files: [new AttachmentBuilder(tempFile, { name: filename })]
            });

            try { fs.unlinkSync(tempFile); } catch (e) {}
        } catch (error) {
            console.error('get error:', error);
            let errorMessage = error.message;
            if (error.response) {
                const s = error.response.status;
                if (s === 401) errorMessage = '🔒 API requires authentication';
                else if (s === 403) errorMessage = '⛔ Access forbidden';
                else if (s === 404) errorMessage = '❌ URL not found (404)';
                else if (s === 429) errorMessage = '📊 Rate limited';
                else if (s === 500) errorMessage = '🔧 Server error';
                else errorMessage = `HTTP ${s}`;
            } else if (error.code === 'ECONNABORTED') errorMessage = '⏰ Request timeout';
            else if (error.code === 'ENOTFOUND') errorMessage = '🌐 Domain not found';
            else if (error.code === 'ECONNREFUSED') errorMessage = '🔌 Connection refused';
            await statusMsg.edit(`❌ error: ${errorMessage}`);
        }
    }
};