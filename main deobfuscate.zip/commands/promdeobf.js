const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { resolveInput } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');
const { runDeobfuscator } = require('../utils/runner');

module.exports = {
    name: 'promdeobf',
    aliases: ['t', 'wd', 'prometheus', 'prometheusdeobf'],
    async execute(message, args) {
        const { content, error } = await resolveInput(message, args);
        if (error || !content) return message.reply(error || 'please provide input.');

        const statusMsg = await message.reply('deobfuscating...');
        const tempDir = os.tmpdir();
        const inputPath = path.join(tempDir, `input_${Date.now()}.lua`);
        const outputPath = path.join(tempDir, `output_${Date.now()}.lua`);

        try {
            fs.writeFileSync(inputPath, content);
            const result = await runDeobfuscator(inputPath, outputPath);
            if (result.error) return statusMsg.edit(`deobfuscation failed: ${result.error}`);
            if (!fs.existsSync(outputPath)) return statusMsg.edit('no output file generated.');

            let outputContent = fs.readFileSync(outputPath, 'utf-8');
            outputContent = addWatermark(outputContent);

            const preview = outputContent.slice(0, 1000) + (outputContent.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('deobfuscated output')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x00ff00)
                .setFooter({ text: `time: ${result.time}ms | size: ${(outputContent.length / 1024).toFixed(2)}kb` });

            const outFilename = generateRandomFilename();
            const tempFile = path.join(tempDir, outFilename);
            fs.writeFileSync(tempFile, outputContent, 'utf-8');

            await statusMsg.edit({
                content: 'deobfuscation complete',
                embeds: [embed],
                files: [new AttachmentBuilder(tempFile, { name: outFilename })]
            });

            try { fs.unlinkSync(tempFile); } catch (e) {}
            try { fs.unlinkSync(inputPath); fs.unlinkSync(outputPath); } catch (e) {}
        } catch (error) {
            console.error('promdeobf error:', error);
            await statusMsg.edit(`error: ${error.message}`);
        }
    }
};