const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { resolveInput } = require('../utils/input');
const { addWatermark, generateRandomFilename } = require('../utils/files');
const { API } = require('../config');

module.exports = {
    name: 'ironbrew',
    aliases: ['ib2', 'ironbrew2'],
    async execute(message, args) {
        const { content, error } = await resolveInput(message, args);
        if (error || !content) return message.reply(error || 'please provide input.');

        const statusMsg = await message.reply('sending to ironbrew deobfuscator...');
        const tempDir = os.tmpdir();
        const randomFilename = generateRandomFilename();
        const tempFile = path.join(tempDir, randomFilename);

        try {
            fs.writeFileSync(tempFile, content);
            const formData = new FormData();
            formData.append('file', fs.createReadStream(tempFile));

            const response = await axios.post(API.IRONBREW, formData, {
                headers: { ...formData.getHeaders() },
                timeout: 60000
            });

            const data = response.data;
            if (!data.success) return statusMsg.edit(`error: ${data.error || 'unknown error'}`);

            let code = data.deobfuscated_code;
            if (!code) return statusMsg.edit('error: no deobfuscated code received');
            code = addWatermark(code);

            const outFilename = generateRandomFilename();
            const outFile = path.join(tempDir, outFilename);
            fs.writeFileSync(outFile, code, 'utf-8');

            const preview = code.slice(0, 1000) + (code.length > 1000 ? '\n... (truncated)' : '');
            const embed = new EmbedBuilder()
                .setTitle('ironbrew deobfuscated')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0x00ff00)
                .addFields(
                    { name: 'size', value: `${data.file?.output_size_kb || (code.length / 1024).toFixed(2)} kb`, inline: true },
                    { name: 'user', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: 'deobfuscated by ironbrew' });

            await statusMsg.edit({
                content: 'ironbrew deobfuscation complete',
                embeds: [embed],
                files: [new AttachmentBuilder(outFile, { name: outFilename })]
            });

            try { fs.unlinkSync(tempFile); fs.unlinkSync(outFile); } catch (e) {}
        } catch (error) {
            console.error('ironbrew error:', error);
            await statusMsg.edit(`error: ${error.message}`);
            try { fs.unlinkSync(tempFile); } catch (e) {}
        }
    }
};