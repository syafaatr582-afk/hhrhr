const fs = require('fs');
const os = require('os');
const path = require('path');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { resolveInput, extractUrl, extractCodeblock } = require('../utils/input');
const { addWatermark, generateRandomFilename, findLatestOutFile } = require('../utils/files');
const { runObfuscator } = require('../utils/runner');
const { OBF_PRESETS } = require('../config');

module.exports = {
    name: 'obf',
    aliases: [],
    async execute(message, args) {
        let preset = 'medium';
        if (args.length > 0 && OBF_PRESETS.includes(args[0].toLowerCase())) {
            preset = args[0].toLowerCase();
            args.shift();
        }

        const { content, error } = await resolveInput(message, args);
        if (error || !content) return message.reply(error || 'please provide input.');

        const statusMsg = await message.reply(`obfuscating with preset: ${preset}...`);
        const tempDir = os.tmpdir();
        const inputPath = path.join(tempDir, `input_${Date.now()}.lua`);
        const outputPath = path.join(tempDir, `output_${Date.now()}.lua`);

        try {
            fs.writeFileSync(inputPath, content);
            const result = await runObfuscator(inputPath, outputPath, preset);
            if (result.error) return statusMsg.edit(`obfuscation failed: ${result.error}`);

            const latestFile = findLatestOutFile();
            let outputContent = null, filePath = null;
            if (latestFile) {
                outputContent = fs.readFileSync(latestFile.path, 'utf-8');
                filePath = latestFile.path;
            } else if (fs.existsSync(outputPath)) {
                outputContent = fs.readFileSync(outputPath, 'utf-8');
                filePath = outputPath;
            }
            if (!outputContent) return statusMsg.edit('no output file generated.');

            outputContent = addWatermark(outputContent);
            const preview = outputContent.slice(0, 1000) + (outputContent.length > 1000 ? '\n... (truncated)' : '');

            const embed = new EmbedBuilder()
                .setTitle('obfuscated output')
                .setDescription(`\`\`\`lua\n${preview}\n\`\`\``)
                .setColor(0xff8c00)
                .setFooter({ text: `preset: ${preset} | time: ${result.time}ms | size: ${(outputContent.length / 1024).toFixed(2)}kb` });

            const outFilename = generateRandomFilename();
            const tempFile = path.join(tempDir, outFilename);
            fs.writeFileSync(tempFile, outputContent, 'utf-8');

            await statusMsg.edit({
                content: 'obfuscation complete',
                embeds: [embed],
                files: [new AttachmentBuilder(tempFile, { name: outFilename })]
            });

            try { fs.unlinkSync(tempFile); } catch (e) {}
            try { fs.unlinkSync(inputPath); fs.unlinkSync(outputPath); } catch (e) {}
        } catch (error) {
            console.error('obf error:', error);
            await statusMsg.edit(`error: ${error.message}`);
        }
    }
};