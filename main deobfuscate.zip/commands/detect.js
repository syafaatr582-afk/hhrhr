const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { extractUrl, extractCodeblock } = require('../utils/input');

const DETECT_API = 'https://leakd.up.railway.app/detect';

/**
 * Ambil konten dari berbagai sumber (reply / attach / URL / codeblock / arg)
 * dan pastikan yang dihasilkan adalah Lua text mentah, bukan HTML wrapper.
 */
async function fetchScriptContent(message, args) {
    let raw = null;
    let source = '';

    // ---- 1) reply ----
    if (message.reference) {
        try {
            const refMsg = await message.channel.messages.fetch(message.reference.messageId);

            if (refMsg.attachments && refMsg.attachments.size > 0) {
                const att = refMsg.attachments.first();
                const r = await axios.get(att.url, { responseType: 'text', timeout: 30000 });
                raw = r.data;
                source = 'reply-attachment';
            } else if (refMsg.content) {
                const url = extractUrl(refMsg.content);
                if (url) {
                    raw = await fetchFromUrl(url);
                    source = 'reply-url';
                } else {
                    const cb = extractCodeblock(refMsg.content);
                    raw = cb || refMsg.content;
                    source = 'reply-text';
                }
            }
        } catch (e) {
            console.error('reply fetch failed:', e.message);
        }
    }

    // ---- 2) own attachment ----
    if (!raw && message.attachments && message.attachments.size > 0) {
        const att = message.attachments.first();
        const r = await axios.get(att.url, { responseType: 'text', timeout: 30000 });
        raw = r.data;
        source = 'attachment';
    }

    // ---- 3) URL / direct arg ----
    if (!raw && args && args.length > 0) {
        const url = extractUrl(args[0]);
        if (url) {
            raw = await fetchFromUrl(url);
            source = 'arg-url';
        } else {
            raw = args.join(' ');
            source = 'arg-text';
        }
    }

    // ---- 4) codeblock in message ----
    if (!raw) {
        const cb = extractCodeblock(message.content);
        if (cb) { raw = cb; source = 'message-codeblock'; }
    }

    return { raw, source };
}

/**
 * Fetch URL — kalau hasilnya HTML dengan paste wrapper,
 * coba ambil link raw di dalamnya atau ekstrak <pre>.
 */
async function fetchFromUrl(url) {
    console.log('[detect] fetching URL:', url);

    const response = await axios.get(url, {
        responseType: 'text',
        timeout: 30000,
        maxRedirects: 10,
        headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; LuaDetectBot/1.0)',
            'Accept': 'text/plain, text/html, application/json, */*'
        }
    });

    let data = response.data;
    const contentType = (response.headers['content-type'] || '').toLowerCase();
    console.log('[detect] content-type:', contentType, '| length:', data.length);

    // Kalau ternyata HTML → coba ekstrak
    if (contentType.includes('text/html') || /^\s*<(!doctype|html)/i.test(data)) {
        console.log('[detect] HTML detected, attempting to extract raw lua...');

        // paste.c-net.org style: ada link raw
        const rawLinkMatch = data.match(/href=["']([^"']*\/raw[^"']*)["']/i);
        if (rawLinkMatch) {
            let rawUrl = rawLinkMatch[1];
            if (rawUrl.startsWith('/')) {
                const u = new URL(url);
                rawUrl = `${u.origin}${rawUrl}`;
            }
            console.log('[detect] following raw link:', rawUrl);
            const rawRes = await axios.get(rawUrl, { responseType: 'text', timeout: 30000 });
            return rawRes.data;
        }

        // pastebin raw pattern (/raw/xxxx)
        const pastebinMatch = url.match(/pastebin\.com\/([A-Za-z0-9]+)/);
        if (pastebinMatch) {
            const rawUrl = `https://pastebin.com/raw/${pastebinMatch[1]}`;
            console.log('[detect] pastebin raw fallback:', rawUrl);
            const rawRes = await axios.get(rawUrl, { responseType: 'text', timeout: 30000 });
            return rawRes.data;
        }

        // generic: ambil isi <pre> atau <textarea>
        const pre = data.match(/<pre[^>]*>([\s\S]*?)<\/pre>/i);
        if (pre) {
            console.log('[detect] extracting <pre> block');
            return pre[1]
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&quot;/g, '"')
                .replace(/&#39;/g, "'");
        }

        const ta = data.match(/<textarea[^>]*>([\s\S]*?)<\/textarea>/i);
        if (ta) {
            console.log('[detect] extracting <textarea> block');
            return ta[1]
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&quot;/g, '"')
                .replace(/&#39;/g, "'");
        }
    }

    // Kalau bukan HTML — anggap sudah lua mentah
    return data;
}

module.exports = {
    name: 'detect',
    aliases: ['det', 'detect', 'd'],
    async execute(message, args) {
        if (!args.length && !message.attachments.size && !message.reference) {
            return message.reply(
                '❌ error: please provide input\n\n' +
                '📌 usage:\n' +
                '.detect <url>\n' +
                '.detect (reply to codeblock/file)\n' +
                '.detect (with .lua file attached)\n' +
                '.detect <direct code>'
            );
        }

        const statusMsg = await message.reply('🔍 extracting script...');

        const tempDir = os.tmpdir();
        let tempFile = null;

        try {
            const { raw, source } = await fetchScriptContent(message, args);

            if (!raw || !raw.trim()) {
                console.log('[detect] extraction returned empty');
                return statusMsg.edit('```\nCould not detect obfuscator or remote loader.\n```');
            }

            // Kalau hasilnya masih HTML → gagal ekstrak
            if (/^\s*<(!doctype|html)/i.test(raw)) {
                console.log('[detect] extracted content is still HTML, aborting');
                return statusMsg.edit('```\nCould not detect obfuscator or remote loader.\n```');
            }

            console.log(`[detect] extracted source=${source} length=${raw.length}`);
            console.log('[detect] first 200 chars:', raw.slice(0, 200).replace(/\n/g, ' '));

            // Kadang script dibungkus codeblock di dalam text → unwrap
            const unwrapped = extractCodeblock(raw) || raw;
            const finalContent = unwrapped.trim();

            if (finalContent.length < 5) {
                console.log('[detect] content too short after unwrap');
                return statusMsg.edit('```\nCould not detect obfuscator or remote loader.\n```');
            }

            // Tulis ke temp file (gunakan .lua supaya server tahu tipe)
            tempFile = path.join(tempDir, `detect_${Date.now()}.lua`);
            fs.writeFileSync(tempFile, finalContent, 'utf-8');

            await statusMsg.edit('🔍 analyzing script...');

            const formData = new FormData();
            formData.append('file', fs.createReadStream(tempFile), {
                filename: 'script.lua',
                contentType: 'text/plain'
            });

            const response = await axios.post(DETECT_API, formData, {
                headers: { ...formData.getHeaders() },
                timeout: 60000,
                validateStatus: () => true
            });

            const data = response.data || {};
            console.log('[detect] API response:', JSON.stringify(data));

            const top = data.top_result || null;
            const obfName = top?.name || null;
            const confidence = top?.confidence ?? null;

            let confidenceStr = 'unknown';
            if (typeof confidence === 'number' && Number.isFinite(confidence)) {
                if (confidence <= 1) confidenceStr = `${(confidence * 100).toFixed(2)}%`;
                else if (Number.isInteger(confidence)) confidenceStr = `${confidence}%`;
                else confidenceStr = `${confidence.toFixed(2)}%`;
            } else if (typeof confidence === 'string' && confidence.length) {
                confidenceStr = confidence;
            }

            const notDetected =
                !data.success ||
                !obfName ||
                obfName.toString().toLowerCase() === 'unknown' ||
                obfName.toString().toLowerCase() === 'none' ||
                obfName.toString().toLowerCase() === 'no match' ||
                (typeof confidence === 'number' && confidence <= 0);

            if (notDetected) {
                return statusMsg.edit('```\nCould not detect obfuscator or remote loader.\n```');
            }

            const output =
                `obfuscators : ${obfName}\n` +
                `confidence  : ${confidenceStr}`;

            await statusMsg.edit('```\n' + output + '\n```');

        } catch (error) {
            console.error('[detect] error:', error.message);
            if (error.response) {
                console.error('[detect] API status:', error.response.status);
                console.error('[detect] API body:', JSON.stringify(error.response.data));
            }
            await statusMsg.edit('```\nCould not detect obfuscator or remote loader.\n```');
        } finally {
            try { if (tempFile && fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (e) {}
        }
    }
};