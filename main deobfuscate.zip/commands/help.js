const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: [],
    async execute(message) {
        const embed = new EmbedBuilder()
            .setTitle('Command Guide')
            .setDescription(
                '**.l** -dump script using oweeee dumper\n' +
                '**.45ms / .45** - env logger with 45ms dumper\n' +
                '**.25ms / .25** - env logger with 25ms dumper\n' +
                '**.upload** - upload to paste.c-net\n' +
                '**.detect / .det** - type obf\n' +
                '**.herdeobf / .herculesdeobf** - dump obf Hercules\n' +
                '**.msdeobf / .moonsec / .moondeobf** - deobf moonsec v3\n' +
                '**.ironbrew / .ib2 / .ironbrew2** - deobf ironbrew2\n' +
                '**.ironveil / .iv** - deobf ironveil\n' +
                '**.t / .promdeobf / .prometheus / .prometheusdeobf** - deobf Prometheus code\n' +
                '**.p2 / .prom2 / .promdeobf2** - deobf Prometheus v2\n' +
                '**.obf** - obf lua\n' +
                '**.rc / .removecomment** - remove comments\n' +
                '**.get / .fetch / .g / .f** - fetch script from URL\n' +
                '**.lb / .luaobfdeobf** - deobf LuaObfuscator\n' +
                '\nall outputs include watermark and are sent as .lua files\n' +
                'timeout: 120 seconds'
            )
            .setColor(0xFFFFFF)
            .setFooter({ text: 'my lie env logger' });
        await message.reply({ embeds: [embed] });
    }
};