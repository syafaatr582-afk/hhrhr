const fs = require('fs');
const os = require('os');
const path = require('path');
const axios = require('axios');
const { EmbedBuilder } = require('discord.js');
const { uploadToPasteCNet } = require('../utils/upload');

module.exports = {
    name: 'upload',
    aliases: ['p', 'up', 'post', 'ul'],
    async execute(message, args) {
        if (!args.length && !message.attachments.size && !message.reference) {
            return message.reply(
                '❌ error: please provide content to upload\n\n' +
                '📌 usage:\n.upload <text>\n.upload (reply)\n.upload (attach file)'
            );
        }

        const statusMsg = await message.reply('🔄 uploading to paste.c-net.org...');

        try {
            let uploadContent = null;
            let fileName = 'upload.txt';
            let isCode = false;
            let detectedLanguage = 'txt';

            // 1) direct args
            if (args.length > 0) {
                const raw = args.join(' ');
                const cb = raw.match(/```(?:\w+)?\s*([\s\S]*?)```/);
                if (cb) {
                    uploadContent = cb[1];
                    isCode = true;
                    const lm = raw.match(/```(\w+)/);
                    if (lm) detectedLanguage = lm[1];
                } else {
                    uploadContent = raw;
                    if (/function|local|print|if|for/.test(uploadContent)) isCode = true;
                }
                fileName = `upload_${Date.now()}.${isCode ? detectedLanguage : 'txt'}`;
            }

            // 2) own attachment
            if (!uploadContent && message.attachments.size > 0) {
                for (const att of message.attachments.values()) {
                    try {
                        const r = await axios.get(att.url, { responseType: 'text', timeout: 30000 });
                        if (r.status === 200 && r.data) {
                            uploadContent = r.data;
                            fileName = att.name || 'upload.txt';
                            const ext = path.extname(fileName).toLowerCase();
                            if (['.lua', '.luau', '.js', '.py', '.rb', '.go', '.rs', '.cpp', '.java', '.cs', '.php', '.html', '.css', '.json', '.xml', '.yaml', '.yml', '.toml', '.ini', '.conf', '.sh', '.bash'].includes(ext)) {
                                isCode = true;
                                detectedLanguage = ext.replace('.', '');
                            }
                            break;
                        }
                    } catch (e) {}
                }
            }

            // 3) reply
            if (!uploadContent && message.reference) {
                try {
                    const refMsg = await message.channel.messages.fetch(message.reference.messageId);
                    if (refMsg.attachments && refMsg.attachments.size > 0) {
                        for (const att of refMsg.attachments.values()) {
                            try {
                                const r = await axios.get(att.url, { responseType: 'text', timeout: 30000 });
                                if (r.status === 200 && r.data) {
                                    uploadContent = r.data;
                                    fileName = att.name || 'reply_upload.txt';
                                    const ext = path.extname(fileName).toLowerCase();
                                    if (['.lua', '.luau', '.js', '.py', '.txt'].includes(ext)) {
                                        isCode = true;
                                        detectedLanguage = ext.replace('.', '');
                                    }
                                    break;
                                }
                            } catch (e) {}
                        }
                    }
                    if (!uploadContent && refMsg.content) {
                        const cb = refMsg.content.match(/```(?:\w+)?\s*([\s\S]*?)```/);
                        if (cb) {
                            uploadContent = cb[1];
                            isCode = true;
                            const lm = refMsg.content.match(/```(\w+)/);
                            if (lm) detectedLanguage = lm[1];
                        } else {
                            uploadContent = refMsg.content;
                        }
                    }
                } catch (e) {}
            }

            if (!uploadContent) return statusMsg.edit('❌ error: could not extract content');

            const tempFile = path.join(os.tmpdir(), fileName);
            fs.writeFileSync(tempFile, uploadContent, 'utf-8');

            await statusMsg.edit('📤 uploading to paste.c-net.org...');
            const result = await uploadToPasteCNet(tempFile);
            if (!result.success) return statusMsg.edit(`❌ upload failed: ${result.error}`);

            const display = uploadContent.length > 1000
                ? uploadContent.slice(0, 1000) + '\n... (truncated)'
                : uploadContent;
            const codeblock = isCode
                ? `\`\`\`${detectedLanguage}\n${display}\n\`\`\``
                : `\`\`\`\n${display}\n\`\`\``;

            const embed = new EmbedBuilder()
                .setTitle('✅ upload successful')
                .setDescription(codeblock)
                .setColor(0x00ff00)
                .addFields(
                    { name: '🔗 link', value: `[click here](${result.url})`, inline: true },
                    { name: '📊 size', value: `${(uploadContent.length / 1024).toFixed(2)} kb`, inline: true },
                    { name: '📂 file', value: fileName, inline: true },
                    { name: '👤 user', value: message.author.toString(), inline: true }
                )
                .setFooter({ text: '📤 uploaded to paste.c-net.org' })
                .setTimestamp();

            await statusMsg.edit({ content: `✅ uploaded to paste.c-net.org`, embeds: [embed] });
            try { fs.unlinkSync(tempFile); } catch (e) {}
        } catch (error) {
            console.error('upload error:', error);
            await statusMsg.edit(`❌ error: ${error.message.slice(0, 1000)}`);
        }
    }
};