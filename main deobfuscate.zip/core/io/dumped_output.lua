--[[
    usage: .l
    54838ms to log everything
]]
local ok_1, err_2 = pcall(function()
local Lighting_1 = game:GetService("Lighting")
end)
local ok_3, err_4 = pcall(function()
local Lighting_1 = game:GetService("Lighting")
end)
local ok_5, err_6 = pcall(function()
local Lighting_1 = game:GetService("Lighting")
end)
local ok_7, err_8 = pcall(function()
local Lighting_1 = game:GetService("Lighting")
end)
local ok_9, err_10 = pcall(function()
local Terrain_2 = workspace:FindFirstChildOfClass("Terrain")
end)
local ok_13, err_14 = pcall(function()
local Terrain_3 = workspace:FindFirstChildOfClass("Terrain")
local ok_11, err_12 = pcall(function()
local Terrain_3 = Terrain_3:ReadVoxels(Region3.new(), 4)
end)
end)
local ok_15, err_16 = pcall(function()
local isLoaded = game:IsLoaded()
end)
local ok_19, err_20 = pcall(function()
local ok_17, err_18 = pcall(function()
local Part_4 = Instance.new("Part")
Part_4.Parent = workspace
local TweenService_5 = game:GetService("TweenService")
local tween_6 = TweenService_5:Create(Part_4, TweenInfo.new(), {
Transparency = 1
})
tween_6:Play()
for _i, _v in pairs({
Transparency = 1
}) do
    Part_4.Transparency = 1
end
task.wait(0.4)
Part_4:Destroy()
end)
end)
local ok_23, err_24 = pcall(function()
local ok_21, err_22 = pcall(function()
local PathfindingService_7 = game:GetService("PathfindingService")
local Path_8 = PathfindingService_7:CreatePath()
local ComputeAsync_9 = Path_8:ComputeAsync(Vector3.new(0, 0, 0), Vector3.new(10, 0, 10))
end)
end)
local ok_27, err_28 = pcall(function()
local ok_25, err_26 = pcall(function()
local Part_10 = Instance.new("Part")
Part_10.Parent = workspace
local CollectionService_11 = game:GetService("CollectionService")
game:GetService("CollectionService") :AddTag(Part_10, "dtc_tag")
local CollectionService_11 = game:GetService("CollectionService")
Part_10:Destroy()
end)
end)
local ok_31, err_32 = pcall(function()
local ok_29, err_30 = pcall(function()
local ContentProvider_12 = game:GetService("ContentProvider")
local PreloadAsync_13 = ContentProvider_12:PreloadAsync({"rbxassetid://1"})
end)
end)
local ok_35, err_36 = pcall(function()
local ok_33, err_34 = pcall(function()
local TextService_14 = game:GetService("TextService")
TextService_14:GetTextSize("test", 14, Enum.Font.SourceSans, Vector2.new(200, 50))
end)
end)
local ok_37, err_38 = pcall(function()
local ProximityPromptService_15 = game:GetService("ProximityPromptService")
end)
local ok_41, err_42 = pcall(function()
local ok_39, err_40 = pcall(function()
local Part_16 = Instance.new("Part")
local Debris_17 = game:GetService("Debris")
local AddItem_18 = Debris_17:AddItem(Part_16, 0.1)
end)
end)
local ok_45, err_46 = pcall(function()
local ok_43, err_44 = pcall(function()
local LogService_19 = game:GetService("LogService")
local logs_20 = LogService_19:GetLogHistory()
end)
end)
local ok_47, err_48 = pcall(function()
local HttpService_21 = game:GetService("HttpService")
local guid_22 = HttpService_21:GenerateGUID(false)
end)
local ok_53, err_54 = pcall(function()
local HttpService_21 = game:GetService("HttpService")
local ok_49, err_50 = pcall(function()
HttpService_21:JSONEncode({
a = 1,
b = "x"
})
end)
local ok_51, err_52 = pcall(function()
HttpService_21:JSONDecode("{\"a\":1,\"b\":\"x\"}")
end)
end)
local ok_55, err_56 = pcall(function()
local HttpService_21 = game:GetService("HttpService")
end)
local ok_59, err_60 = pcall(function()
local ok_57, err_58 = pcall(function()
local Part_23 = Instance.new("Part")
end)
end)
local ok_61, err_62 = pcall(function()
local Part_24 = Instance.new("Part")
Part_24.Name = "dtc_p"
Part_24.Parent = workspace
local fullName = Part_24:GetFullName()
Part_24:Destroy()
end)
local ok_63, err_64 = pcall(function()
local Part_25 = Instance.new("Part")
end)
local ok_65, err_66 = pcall(function()
local Model_26 = Instance.new("Model")
local Part_27 = Instance.new("Part")
Part_27.Parent = Model_26
local Part_28 = Instance.new("Part")
Part_28.Parent = Model_26
end)
local ok_67, err_68 = pcall(function()
local Part_29 = Instance.new("Part")
Part_29.Name = "dtc_orig"
local PartClone_30 = Part_29:Clone()
end)
local ok_69, err_70 = pcall(function()
local Part_31 = Instance.new("Part")
Part_31.Parent = workspace
local conn_32 = Part_31.Changed:Connect(function(prop)
end)
Part_31.Transparency = 0.5
task.wait(0.1)
conn_32:Disconnect()
Part_31:Destroy()
end)
local ok_71, err_72 = pcall(function()
local Part_33 = Instance.new("Part")
Part_33.Parent = workspace
local conn_34 = Part_33:GetPropertyChangedSignal("Transparency") :Connect(function(prop)
end)
Part_33.Transparency = 0.7
task.wait(0.1)
conn_34:Disconnect()
Part_33:Destroy()
end)
local ok_75, err_76 = pcall(function()
local ok_73, err_74 = pcall(function()
local Part_35 = Instance.new("Part")
Part_35.Parent = workspace
local Part_36 = Instance.new("Part")
Part_36.Parent = workspace
local WeldConstraint_37 = Instance.new("WeldConstraint")
WeldConstraint_37.Part0 = Part_35
WeldConstraint_37.Part1 = Part_36
WeldConstraint_37.Parent = Part_35
Part_35:Destroy()
Part_36:Destroy()
end)
end)
local ok_79, err_80 = pcall(function()
local ok_77, err_78 = pcall(function()
local Model_38 = Instance.new("Model")
local Humanoid_39 = Instance.new("Humanoid")
Humanoid_39.MaxHealth = 100
Humanoid_39.Health = 100
Humanoid_39.Parent = Model_38
Humanoid_39:TakeDamage(20)
Model_38:Destroy()
end)
end)
local ok_83, err_84 = pcall(function()
local ok_81, err_82 = pcall(function()
local BodyVelocity_40 = Instance.new("BodyVelocity")
BodyVelocity_40.Velocity = Vector3.new(0, 10, 0)
local Part_41 = Instance.new("Part")
Part_41.Anchored = false
Part_41.Parent = workspace
BodyVelocity_40.Parent = Part_41
task.wait(0.2)
Part_41:Destroy()
end)
end)
local ok_87, err_88 = pcall(function()
local ok_85, err_86 = pcall(function()
local Part_42 = Instance.new("Part")
Part_42.Parent = workspace
local ForceField_43 = Instance.new("ForceField")
ForceField_43.Parent = Part_42
Part_42:Destroy()
end)
end)
local ok_91, err_92 = pcall(function()
local ok_89, err_90 = pcall(function()
local Explosion_44 = Instance.new("Explosion")
end)
end)
local ok_93, err_94 = pcall(function()
local Part_45 = Instance.new("Part")
Part_45.Size = Vector3.new(100, 100, 100)
Part_45.Anchored = true
Part_45.Parent = workspace
local partBounds_46 = workspace:GetPartBoundsInBox(CFrame.new(), Vector3.new(100, 100, 100), "nil")
for _i, _v in pairs({
[Lighting_1] = {
ClockTime = 12,
ColorShift_Bottom = Color3.new(0, 0, 0),
FogEnd = 100000,
ExposureCompensation = 0,
ShadowMap = true,
EnvironmentDiffuseScale = 1,
EnvironmentSpecularScale = 1,
Name = "Lighting",
GeographicLatitude = 41.7,
Ambient = Color3.new(0.78, 0.78, 0.78),
OutdoorAmbient = Color3.new(0.78, 0.78, 0.78),
TimeOfDay = "12:00:00",
Brightness = 2,
ColorShift_Top = Color3.new(0, 0, 0),
ClassName = "Lighting"
},
[nil] = {},
[nil] = {
Size = Vector3.new(2, 2, 1),
Name = "HumanoidRootPart",
ClassName = "Part"
},
[Enum.CameraType.Custom] = {
Value = 0,
EnumType = nil,
Name = "Custom"
},
[nil] = {},
[PreloadAsync_13] = {},
[nil] = {
Name = "Completed",
ClassName = "BindableEvent"
},
[Part_36] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[nil] = {},
[PathfindingService_7] = {
Name = "PathfindingService",
ClassName = "PathfindingService"
},
[nil] = {},
[nil] = {
Name = "Terrain",
ClassName = "Terrain"
},
[Debris_17] = {
Name = "Debris",
ClassName = "Debris"
},
[nil] = {},
[Part_33:GetPropertyChangedSignal("Transparency")] = {
callbacks = {function(...)
end}
},
[script.Parent] = {
Name = "PlayerScripts",
ClassName = "PlayerScripts"
},
[Part_24] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "dtc_p",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Part_23] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Enum.Font.SourceSans] = {
Value = 1,
EnumType = nil,
Name = "SourceSans"
},
[nil] = {},
[nil] = {},
[Part_28] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
Parent = Model_26,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[nil] = {
Enabled = true,
Size = 10,
Name = "Blur",
ClassName = "BlurEffect"
},
[workspace] = {
CurrentCamera = nil,
Name = "Workspace",
ClassName = "Workspace",
SimulationRadius = 1000,
Gravity = 196.2,
StreamingPauseMode = Enum.StreamingPauseMode.Default,
StreamingEnabled = false
},
[nil] = {
Character = nil,
Name = "LocalPlayer",
ClassName = "Player",
UserId = 1,
DisplayName = "LocalPlayer"
},
[partBounds_46] = {},
[nil] = {},
[nil] = {},
[nil] = {},
[WeldConstraint_37] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
_mass = 1.5,
_transform = CFrame.new(),
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
Part1 = Part_36,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "WeldConstraint",
ClassName = "WeldConstraint",
Part0 = Part_35,
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Explosion_44] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Explosion",
ClassName = "Explosion",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[nil] = {},
[nil] = {},
[nil] = {},
[nil] = {},
[Part_42] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Part_41] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Terrain_3] = {},
[BodyVelocity_40] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
Velocity = Vector3.new(0, 10, 0),
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "BodyVelocity",
ClassName = "BodyVelocity",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Humanoid_39] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
Health = 80,
MaxHealth = 100,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Humanoid",
ClassName = "Humanoid",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Model_38] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Model",
ClassName = "Model",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Part_25] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Part_45] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = true,
_enabled = true,
Parent = workspace,
Size = Vector3.new(100, 100, 100),
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Part_35] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[nil] = {},
[conn_34] = {
Connected = false
},
[Model_26] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
__cc = {Part_28, Part_27},
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Model",
ClassName = "Model",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[HttpService_21] = {
HttpEnabled = true,
Name = "HttpService",
ClassName = "HttpService"
},
[Part_31.Changed] = {
callbacks = {function(...)
end}
},
[Enum.Technology.None] = {
Value = 0,
EnumType = nil,
Name = "None"
},
[nil] = {},
[ContentProvider_12] = {
BaseUrl = "https://www.roblox.com/",
Name = "ContentProvider",
ClassName = "ContentProvider"
},
[nil] = {},
[nil] = {
LocalPlayer = nil,
Name = "Players",
ClassName = "Players"
},
[nil] = {},
[ComputeAsync_9] = {},
[nil] = {
Name = "Baseplate",
ClassName = "Part"
},
[ForceField_43] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "ForceField",
ClassName = "ForceField",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[nil] = {},
[Part_31] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
Transparency = 0.5,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[PartClone_30] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
_smoothTime = 0,
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_scale = 1,
Position = Vector3.new(0, 0, 0),
CanCollide = false,
_transform = CFrame.new(),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
ClassName = "Part",
_smoothedTarget = CFrame.new(),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
Name = "dtc_orig",
_rules = {},
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_entries = {}
},
[nil] = {},
[Terrain_2] = {},
[Part_27] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
Parent = Model_26,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Enum.CreatorType.User] = {
Value = 0,
EnumType = nil,
Name = "User"
},
[Part_29] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = { --[[circular]]},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = { --[[circular]]},
_smoothedTarget = CFrame.new(),
Name = "dtc_orig",
ClassName = "Part",
_transform = CFrame.new(),
_rules = { --[[circular]]},
_scale = 1,
_smoothTime = 0
},
[nil] = {},
[nil] = {},
[nil] = {},
[guid_22] = {},
[nil] = {},
[logs_20] = {},
[ProximityPromptService_15] = {
Name = "ProximityPromptService",
ClassName = "ProximityPromptService"
},
[Enum.PlaybackState.Begin] = {
Value = 1,
EnumType = nil,
Name = "Begin"
},
[TweenService_5] = {
TweenInfoNumber = 0,
Name = "TweenService",
ClassName = "TweenService"
},
[Part_33] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_signals = {
Transparency = Part_33:GetPropertyChangedSignal("Transparency")
},
Transparency = 0.7,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[nil] = {},
[nil] = {
Source = "print('Animate')",
Name = "Animate",
ClassName = "LocalScript"
},
[nil] = {},
[nil] = {},
[AddItem_18] = {},
[nil] = {},
[nil] = {},
[LogService_19] = {
Name = "LogService",
ClassName = "LogService"
},
[nil] = {},
[conn_32] = {
Connected = false
},
[Part_4] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
Transparency = 1,
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[Enum.PlaybackState.Playing] = {
Value = 1,
EnumType = nil,
Name = "Playing"
},
[Path_8] = {
Status = nil
},
[nil] = {},
[Part_10] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
tags = {
dtc_tag = true
},
_enabled = true,
__destroyed = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[CollectionService_11] = {
Name = "CollectionService",
ClassName = "CollectionService"
},
[tween_6] = {
PlaybackState = Enum.PlaybackState.Playing,
goals = {
Transparency = 1
},
ClassName = "Tween",
target = Part_4,
Completed = nil,
tweenInfo = TweenInfo.new()
},
[Enum.Material.Air] = {
Value = 1792,
EnumType = nil,
Name = "Air"
},
[game] = {
PlaceVersion = 1,
CreatorId = 0,
Name = "Game",
GameId = 8916037983,
IsLoaded = true,
PlaceId = 8916037983,
ClassName = "DataModel",
CreatorType = Enum.CreatorType.User
},
[nil] = {
ViewportSize = Vector2.new(1920, 1080),
FieldOfView = 70,
Name = "Camera",
ClassName = "Camera",
CFrame = CFrame.new(),
NearPlaneZ = - 0.1,
CameraType = Enum.CameraType.Custom
},
[Part_16] = {
_rawTarget = CFrame.new(),
_weight = 1,
Anchored = false,
_enabled = true,
AssemblyCenterOfMass = Vector3.new(0, 0, 0),
_distanceAttenuation = {
[0] = 1,
[20] = 0,
[10] = 0.5
},
AssemblyAngularVelocity = Vector3.new(0, 0, 0),
_mass = 1.5,
_velocity = Vector3.new(0, - 50, 0),
CanCollide = false,
Position = Vector3.new(0, 0, 0),
AssemblyMass = 1.5,
_target = CFrame.new(),
AssemblyLinearVelocity = Vector3.new(0, - 50, 0),
_entries = {},
_smoothedTarget = CFrame.new(),
Name = "Part",
ClassName = "Part",
_transform = CFrame.new(),
_rules = {},
_scale = 1,
_smoothTime = 0
},
[TextService_14] = {
TextFilteringEnabled = true,
Name = "TextService",
ClassName = "TextService"
},
[nil] = {
Humanoid = nil,
Name = "LocalPlayer",
ClassName = "Model",
HumanoidRootPart = nil,
Animate = nil
},
[nil] = {
Enabled = true,
Name = "ColorCorrection",
ClassName = "ColorCorrectionEffect",
Tiny = 0,
Brightness = 0,
Saturation = 0,
Contrast = 0
},
[Vector2.new(0, 0)] = {
Y = 20,
X = 100
},
[Enum.StreamingPauseMode.Default] = {
Value = 1,
EnumType = nil,
Name = "Default"
},
[nil] = {},
[script] = {},
[nil] = {
Name = "Humanoid",
ClassName = "Humanoid"
},
[nil] = {},
[Enum] = {}
}) do
end)
local ok_97, err_98 = pcall(function()
local ok_95, err_96 = pcall(function()
local SoundGroup_47 = Instance.new("SoundGroup")
SoundGroup_47.Volume = 0.5
local Sound_48 = Instance.new("Sound")
Sound_48.SoundGroup = SoundGroup_47
end)
end)
local ok_101, err_102 = pcall(function()
local ok_99, err_100 = pcall(function()
local Attachment_49 = Instance.new("Attachment")
Attachment_49.Position = Vector3.new(1, 1, 1)
end)
end)
local ok_105, err_106 = pcall(function()
local ok_103, err_104 = pcall(function()
local ParticleEmitter_50 = Instance.new("ParticleEmitter")
ParticleEmitter_50.Rate = 10
local Part_51 = Instance.new("Part")
ParticleEmitter_50.Parent = Part_51
end)
end)
local ok_109, err_110 = pcall(function()
local ok_107, err_108 = pcall(function()
local Attachment_52 = Instance.new("Attachment")
local Attachment_53 = Instance.new("Attachment")
local Trail_54 = Instance.new("Trail")
Trail_54.Attachment0 = Attachment_52
Trail_54.Attachment1 = Attachment_53
end)
end)
local ok_113, err_114 = pcall(function()
local ok_111, err_112 = pcall(function()
local Attachment_55 = Instance.new("Attachment")
local Attachment_56 = Instance.new("Attachment")
local Beam_57 = Instance.new("Beam")
Beam_57.Attachment0 = Attachment_55
Beam_57.Attachment1 = Attachment_56
end)
end)
local ok_117, err_118 = pcall(function()
local ok_115, err_116 = pcall(function()
local ContextActionService_58 = game:GetService("ContextActionService")
ContextActionService_58:BindAction("dtc", function()end, false)
local ContextActionService_58 = game:GetService("ContextActionService")
ContextActionService_58:UnbindAction("dtc")
end)
end)
local ok_121, err_122 = pcall(function()
local ok_119, err_120 = pcall(function()
local GuiService_59 = game:GetService("GuiService")
GuiService_59:GetGuiInset()
end)
end)
local ok_125, err_126 = pcall(function()
local ok_123, err_124 = pcall(function()
local StarterGui_60 = game:GetService("StarterGui")
StarterGui_60:SetCore(""SendNotification"", {
Title = "t",
Text = "t"
})
end)
end)
local ok_127, err_128 = pcall(function()
local TextChatService_61 = game:GetService("TextChatService")
end)
local ok_129, err_130 = pcall(function()
local RunService_62 = game:GetService("RunService")
local isClient = RunService_62:IsClient()
local isServer = RunService_62:IsServer()
end)
local ok_131, err_132 = pcall(function()
local RunService_62 = game:GetService("RunService")
local isStudio = RunService_62:IsStudio()
end)
local ok_135, err_136 = pcall(function()
local ok_133, err_134 = pcall(function()
local RunService_62 = game:GetService("RunService")
local conn_63 = RunService_62.RenderStepped:Connect(function(dt)
end)
end)
conn_63:Disconnect()
end)
local ok_137, err_138 = pcall(function()
local RunService_62 = game:GetService("RunService")
local conn_64 = RunService_62.Stepped:Connect(function(t, dt)
end)
task.wait(0.2)
conn_64:Disconnect()
end)
local ok_139, err_140 = pcall(function()
local Players_65 = game:GetService("Players")
end)
local ok_141, err_142 = pcall(function()
local Players_65 = game:GetService("Players")
end)
local ok_143, err_144 = pcall(function()
local Players_65 = game:GetService("Players")
end)
local ok_145, err_146 = pcall(function()
local Players_65 = game:GetService("Players")
end)
local ok_147, err_148 = pcall(function()
local Players_65 = game:GetService("Players")
end)
local ok_149, err_150 = pcall(function()
local Players_65 = game:GetService("Players")
end)
local ok_151, err_152 = pcall(function()
local Players_65 = game:GetService("Players")
end)
local ok_155, err_156 = pcall(function()
local Model_67 = Instance.new("Model")
local Humanoid_68 = Instance.new("Humanoid")
Humanoid_68.Parent = Model_67
local Part_69 = Instance.new("Part")
Part_69.Name = "HumanoidRootPart"
Part_69.Parent = Model_67
local ok_153, err_154 = pcall(function()
Humanoid_68:MoveTo(Vector3.new(5, 0, 5))
end)
Model_67:Destroy()
end)
local ok_159, err_160 = pcall(function()
local ok_157, err_158 = pcall(function()
local Animation_70 = Instance.new("Animation")
Animation_70.AnimationId = "rbxassetid://1"
end)
end)
local ok_163, err_164 = pcall(function()
local ok_161, err_162 = pcall(function()
local BadgeService_71 = game:GetService("BadgeService")
local UserHasBadgeAsync_72 = BadgeService_71:UserHasBadgeAsync(1, 1)
end)
end)
local ok_165, err_166 = pcall(function()
local SocialService_73 = game:GetService("SocialService")
end)
local ok_169, err_170 = pcall(function()
local ok_167, err_168 = pcall(function()
local GamePassService_74 = game:GetService("GamePassService")
end)
end)
local ok_173, err_174 = pcall(function()
local ok_171, err_172 = pcall(function()
local LocalizationService_75 = game:GetService("LocalizationService")
local GetCountryRegionForPlayerAsync_76 = LocalizationService_75:GetCountryRegionForPlayerAsync(nil)
end)
end)
local ok_175, err_176 = pcall(function()
local VRService_77 = game:GetService("VRService")
local VRService_77 = game:GetService("VRService")
end)
local ok_177, err_178 = pcall(function()
local HapticService_78 = game:GetService("HapticService")
end)
local ok_181, err_182 = pcall(function()
local ok_179, err_180 = pcall(function()
local TeleportService_79 = game:GetService("TeleportService")
local teleData = TeleportService_79:GetLocalPlayerTeleportData()
end)
end)
local ok_183, err_184 = pcall(function()
local StarterPack_80 = game:GetService("StarterPack")
end)
local ok_185, err_186 = pcall(function()
local StarterGui_60 = game:GetService("StarterGui")
end)
local ok_189, err_190 = pcall(function()
local ok_187, err_188 = pcall(function()
local Chat_81 = game:GetService("Chat")
local FilterStringForBroadcast_82 = Chat_81:FilterStringForBroadcast("test", nil)
end)
end)
local ok_191, err_192 = pcall(function()
local Workspace_83 = game:GetService("Workspace")
end)
local ok_193, err_194 = pcall(function()
local ReplicatedStorage_84 = game:GetService("ReplicatedStorage")
end)
local ok_195, err_196 = pcall(function()
local ReplicatedFirst_85 = game:GetService("ReplicatedFirst")
end)
local ok_199, err_200 = pcall(function()
local ok_197, err_198 = pcall(function()
local ServerStorage_86 = game:GetService("ServerStorage")
end)
end)
local ok_203, err_204 = pcall(function()
local ok_201, err_202 = pcall(function()
local ServerScriptService_87 = game:GetService("ServerScriptService")
end)
end)
local ok_205, err_206 = pcall(function()
local SoundService_88 = game:GetService("SoundService")
end)
local RunService_62 = game:GetService("RunService")
RunService_62.Heartbeat:Wait()
-- timed out after 30s