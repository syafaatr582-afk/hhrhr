local PrismV2 = select(2, pcall(function()
 local b = workspace.CurrentCamera.CFrame.Position + Vector3.new(0, 1000, 0)
 local a = Instance.new("Part")
 a.Anchored = true
 a.Size = Vector3.new(10, 2, 10)
 a.CFrame = CFrame.new(b)
 a.Material = Enum.Material.Neon
 a.Parent = workspace
 local pr = RaycastParams.new()
 pr.FilterType = Enum.RaycastFilterType.Include
 pr.FilterDescendantsInstances = {a}
 local r = workspace:Raycast(b + Vector3.new(0, 50, 0), Vector3.new(0, -100, 0), pr)
 local m = workspace:Raycast(b + Vector3.new(0, 50, 0), Vector3.new(0, 30, 0), pr)
 local ok = r ~= nil and r.Instance == a and r.Normal:FuzzyEq(Vector3.yAxis) and math.abs(r.Position.Y - (b.Y + 1)) < 0.01 and math.abs(r.Distance - 49) < 0.01 and r.Material == Enum.Material.Neon and m == nil
 a:Destroy()
 return ok
end)) == true
print(PrismV2 and "pass" or "fail")