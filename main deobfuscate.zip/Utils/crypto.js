function base32Decode(input) {
    const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    input = input.toUpperCase().replace(/=+$/, '').replace(/\s/g, '');
    const output = [];
    let buffer = 0, bitsLeft = 0;
    for (let i = 0; i < input.length; i++) {
        const charIdx = ALPHABET.indexOf(input[i]);
        if (charIdx === -1) throw new Error(`Invalid Base32 character: "${input[i]}" at position ${i}`);
        buffer = (buffer << 5) | charIdx;
        bitsLeft += 5;
        if (bitsLeft >= 8) {
            bitsLeft -= 8;
            output.push((buffer >>> bitsLeft) & 0xFF);
        }
    }
    return new Uint8Array(output);
}

function xorDecrypt(data, key) {
    const keyBytes = new TextEncoder().encode(key);
    const result = new Uint8Array(data.length);
    for (let i = 0; i < data.length; i++) result[i] = data[i] ^ keyBytes[i % keyBytes.length];
    return new TextDecoder('utf-8').decode(result);
}

function decryptEncryptX(scriptContent) {
    try {
        let jsonData;
        try { jsonData = JSON.parse(scriptContent); } catch (e) { return scriptContent; }

        if (jsonData.Script && jsonData.Key) {
            const decoded = base32Decode(jsonData.Script);
            return xorDecrypt(decoded, jsonData.Key);
        }
        if (jsonData.Script) return jsonData.Script;
        if (jsonData.data)   return jsonData.data;
        throw new Error('Invalid encrypt-x format');
    } catch (error) {
        throw new Error('Decryption failed: ' + error.message);
    }
}

module.exports = { base32Decode, xorDecrypt, decryptEncryptX };