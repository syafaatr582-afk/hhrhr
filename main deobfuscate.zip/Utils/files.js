const fs = require('fs');
const path = require('path');
const { WATERMARK, PATHS } = require('../config');

if (!fs.existsSync(PATHS.CORE_DIR)) fs.mkdirSync(PATHS.CORE_DIR, { recursive: true });
if (!fs.existsSync(PATHS.OUT_DIR))  fs.mkdirSync(PATHS.OUT_DIR,  { recursive: true });

function addWatermark(content) {
    return WATERMARK + content;
}

function generateRandomFilename() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 15; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
    return result + '.lua';
}

function findLatestOutFile() {
    try {
        if (!fs.existsSync(PATHS.OUT_DIR)) return null;
        const files = fs.readdirSync(PATHS.OUT_DIR).filter(f => f.endsWith('.lua'));
        if (files.length === 0) return null;
        const sorted = files.map(f => ({
            name: f,
            path: path.join(PATHS.OUT_DIR, f),
            time: fs.statSync(path.join(PATHS.OUT_DIR, f)).mtimeMs
        })).sort((a, b) => b.time - a.time);
        return sorted[0];
    } catch (error) {
        console.error('error finding latest out file:', error);
        return null;
    }
}

module.exports = { addWatermark, generateRandomFilename, findLatestOutFile };