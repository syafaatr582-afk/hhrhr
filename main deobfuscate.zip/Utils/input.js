const axios = require('axios');
const path = require('path');
const { MAX_FILE_SIZE } = require('../config');

const HTTP = axios.create({
    timeout: 10000,
    maxContentLength: MAX_FILE_SIZE,
    maxBodyLength: MAX_FILE_SIZE,
    responseType: 'arraybuffer',
    validateStatus: s => s === 200
});

const EXT_OK = new Set(['.lua', '.luau', '.txt']);
const CODEBLOCK_RE = /```(?:lua|luau)?\s*([\s\S]*?)```/;

async function fetchUrl(url) {
    const res = await HTTP.get(url);
    return Buffer.from(res.data);
}

async function getInputContent(message, arg) {
    if (arg && /^https?:\/\//i.test(arg)) {
        try {
            return (await fetchUrl(arg)).toString('utf-8');
        } catch (e) {
            console.error('fetch url:', e.message);
        }
    }

    if (message.attachments && message.attachments.size > 0) {
        const att = message.attachments.find(a => EXT_OK.has(path.extname(a.name || '').toLowerCase()));
        if (att) {
            try {
                return (await fetchUrl(att.url)).toString('utf-8');
            } catch (e) {
                console.error('fetch attachment:', e.message);
            }
        }
    }

    if (message.reference) {
        try {
            const ref = await message.channel.messages.fetch(message.reference.messageId);
            if (ref) {
                if (ref.attachments.size > 0) {
                    const att = ref.attachments.find(a => EXT_OK.has(path.extname(a.name || '').toLowerCase()));
                    if (att) {
                        try {
                            return (await fetchUrl(att.url)).toString('utf-8');
                        } catch (e) {
                            console.error('fetch reply attachment:', e.message);
                        }
                    }
                }
                const url = extractUrl(ref.content);
                if (url) {
                    try {
                        return (await fetchUrl(url)).toString('utf-8');
                    } catch (e) {
                        console.error('fetch reply url:', e.message);
                    }
                }
                const cb = extractCodeblock(ref.content);
                if (cb) return cb;
                if (ref.content) return ref.content;
            }
        } catch (e) {
            console.error('fetch reply:', e.message);
        }
    }

    if (arg) return arg;
    return null;
}

function extractCode(content) {
    if (!content) return content;
    let out = content;

    const cb = out.match(CODEBLOCK_RE);
    if (cb) out = cb[1].trim();

    const ls = out.match(/loadstring\(['"]([^'"]+)['"]\)/);
    if (ls) {
        try { out = decodeURIComponent(ls[1]); } catch (e) {}
    }

    const b64 = out.match(/base64\.decode\(['"]([^'"]+)['"]\)/);
    if (b64) {
        try { out = Buffer.from(b64[1], 'base64').toString('utf-8'); } catch (e) {}
    }

    return out;
}

function extractUrl(text) {
    if (!text) return null;
    const m = text.match(/https?:\/\/[^\s<>"']+/);
    return m ? m[0] : null;
}

function extractCodeblock(text) {
    if (!text) return null;
    const m = text.match(CODEBLOCK_RE);
    return m ? m[1] : null;
}

async function resolveInput(message, args) {
    let content = null;
    let filename = null;
    let err = null;

    // 1) reply
    if (message.reference) {
        try {
            const ref = await message.channel.messages.fetch(message.reference.messageId);

            if (ref.attachments && ref.attachments.size > 0) {
                const att = ref.attachments.first();
                if (att && att.size <= MAX_FILE_SIZE) {
                    const ext = path.extname(att.filename || '').toLowerCase() || '.txt';
                    if (EXT_OK.has(ext)) {
                        content = await fetchUrl(att.url);
                        filename = att.filename || `input${ext}`;
                    } else {
                        err = `only .lua, .luau, and .txt files are supported (got: ${ext})`;
                    }
                } else if (att) {
                    err = `file too large (max 10mb) - size: ${(att.size / 1024 / 1024).toFixed(2)}mb`;
                }
            } else if (ref.content) {
                const url = extractUrl(ref.content);
                if (url) {
                    try {
                        content = await fetchUrl(url);
                        filename = path.basename(url);
                    } catch (e) {
                        err = `failed to fetch url: ${e.message}`;
                    }
                } else {
                    const cb = extractCodeblock(ref.content);
                    if (cb) {
                        content = Buffer.from(cb, 'utf-8');
                        filename = 'reply.lua';
                    }
                }
            }
        } catch (e) {
            err = `failed to fetch reply: ${e.message}`;
        }
    }

    // 2) own attachment
    if (!content && !err && message.attachments && message.attachments.size > 0) {
        const att = message.attachments.first();
        if (att && att.size <= MAX_FILE_SIZE) {
            try {
                const ext = path.extname(att.filename || '').toLowerCase() || '.txt';
                if (EXT_OK.has(ext)) {
                    content = await fetchUrl(att.url);
                    filename = att.filename || `input${ext}`;
                } else {
                    err = `only .lua, .luau, and .txt files are supported (got: ${ext})`;
                }
            } catch (e) {
                err = `failed to download attachment: ${e.message}`;
            }
        } else if (att) {
            err = `file too large (max 10mb) - size: ${(att.size / 1024 / 1024).toFixed(2)}mb`;
        }
    }

    // 3) args
    if (!content && !err && args && args.length > 0) {
        const url = extractUrl(args[0]);
        if (url) {
            try {
                content = await fetchUrl(url);
                filename = path.basename(url);
            } catch (e) {
                err = `failed to fetch url: ${e.message}`;
            }
        } else {
            content = Buffer.from(args.join(' '), 'utf-8');
            filename = 'input.lua';
        }
    }

    // 4) codeblock
    if (!content && !err) {
        const cb = extractCodeblock(message.content);
        if (cb) {
            content = Buffer.from(cb, 'utf-8');
            filename = 'codeblock.lua';
        }
    }

    return { content, filename, error: err };
}

module.exports = {
    getInputContent,
    extractCode,
    extractUrl,
    extractCodeblock,
    resolveInput
};