const { spawn } = require('child_process');
const path = require('path');
const { TIMEOUT } = require('../config');

// lune.exe ada di folder yang sama dengan file ini
const LUNE_PATH = path.join(__dirname, 'lune.exe');

/**
 * Generic child-process runner.
 */
function runProcess(bin, args, label = 'proc', timeout = TIMEOUT) {
    return new Promise((resolve) => {
        const startTime = Date.now();
        const proc = spawn(bin, args);
        let stderr = '';
        let stdout = '';

        proc.stdout.on('data', (d) => {
            stdout += d.toString();
            console.log(`[${label} STDOUT] ${d.toString().trim()}`);
        });
        proc.stderr.on('data', (d) => {
            stderr += d.toString();
            console.log(`[${label} STDERR] ${d.toString().trim()}`);
        });

        proc.on('close', (code) => {
            const time = Date.now() - startTime;
            if (code !== 0) {
                resolve({ error: stderr || `process exited with code ${code}`, time });
            } else {
                resolve({ success: true, time, stdout });
            }
        });

        proc.on('error', (err) => {
            resolve({ error: `spawn ${bin} failed: ${err.message}`, time: Date.now() - startTime });
        });

        setTimeout(() => {
            proc.kill();
            resolve({ error: `${label} timeout (${timeout / 1000}s)`, time: Date.now() - startTime });
        }, timeout);
    });
}

// ---- Obfuscator (obf.js) ----
function runObfuscator(inputPath, outputPath, preset) {
    return runProcess('node', ['obf.js', preset, inputPath, outputPath], 'OBF');
}

// ---- Prometheus deobf (main.js) ----
function runDeobfuscator(inputPath, outputPath) {
    return runProcess('node', ['main.js', inputPath, outputPath], 'DEOBF');
}

// ---- Lune runner ----
function runLune(script, inputPath, outputPath, label = 'LUNE') {
    return runProcess('lune', ['run', script, inputPath, outputPath], label);
}

// ---- Python runner (hercules) ----
function runPython(script, args, label = 'PY') {
    return runProcess('python', [script, ...args], label);
}

module.exports = {
    runProcess,
    runObfuscator,
    runDeobfuscator,
    runLune,
    runPython,
};