const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const axios = require('axios');
const { spawn } = require('child_process');
const FormData = require('form-data');

const httpAgent = new http.Agent({ keepAlive: true, maxSockets: 50 });
const httpsAgent = new https.Agent({ keepAlive: true, maxSockets: 50 });
const UA = 'curl/7.68.0';

function uploadWithCurl(filePath) {
    return new Promise((resolve, reject) => {
        const proc = spawn('curl', [
            '--upload-file', filePath,
            'https://paste.c-net.org/',
            '-L', '-s', '--max-time', '10',
            '-w', '%{url_effective}'
        ]);
        let out = '', err = '';
        const timer = setTimeout(() => {
            proc.kill('SIGKILL');
            reject(new Error('curl timeout'));
        }, 12000);
        proc.stdout.on('data', d => out += d);
        proc.stderr.on('data', d => err += d);
        proc.on('close', code => {
            clearTimeout(timer);
            if (code !== 0) return reject(new Error(`curl exit ${code}: ${err}`));
            const url = out.trim();
            if (url.startsWith('http')) resolve({ success: true, url, rawUrl: `${url}/raw` });
            else reject(new Error('invalid url from curl'));
        });
        proc.on('error', e => { clearTimeout(timer); reject(e); });
    });
}

async function uploadToPasteCNet(filePath) {
    try {
        const buf = fs.readFileSync(filePath);
        const form = new FormData();
        form.append('file', buf, { filename: path.basename(filePath), contentType: 'text/plain' });

        const res = await axios.post('https://paste.c-net.org/', form, {
            headers: { ...form.getHeaders(), 'User-Agent': UA },
            maxRedirects: 0,
            validateStatus: s => s >= 200 && s < 400,
            timeout: 8000,
            httpAgent,
            httpsAgent
        });

        let url = res.headers.location ||
                  res.headers['x-paste-url'] ||
                  (res.data && res.data.url) || null;

        if (url && !url.startsWith('http')) {
            url = `https://paste.c-net.org${url.startsWith('/') ? '' : '/'}${url}`;
        }
        if (!url) throw new Error('no paste url');

        return { success: true, url, rawUrl: `${url}/raw` };
    } catch (e) {
        try {
            return await uploadWithCurl(filePath);
        } catch (ce) {
            return { success: false, error: e.message };
        }
    }
}

module.exports = { uploadToPasteCNet, uploadWithCurl };